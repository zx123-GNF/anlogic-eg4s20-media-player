//=============================================================================
//  m4_i2s_tx.v  --  I2S transmitter, FPGA is master (M4)

`timescale 1ns / 10ps

module m4_i2s_tx (
    input  wire        I_clk,
    input  wire        I_rst,
    input  wire        I_en,
    input  wire [15:0] I_sample,
    output reg         O_tick,

    output wire        O_mclk,
    output reg         O_bclk,
    output reg         O_lrck,
    output reg         O_dacdat,
    output reg         O_adclrc
);

    assign O_mclk = I_clk;

    reg [1:0] S_mcnt;
    reg [5:0] S_slot;
    reg [15:0] S_sl;
    reg [15:0] S_sr;

    wire [5:0] S_nslot = S_slot + 6'd1;
    wire [4:0] S_off   = S_nslot[4:0];
    wire [15:0] S_src  = S_nslot[5] ? S_sr : S_sl;
    wire [3:0] S_bidx  = (5'd16 - S_off);
    wire       S_bitv  = ((S_off >= 5'd1) && (S_off <= 5'd16)) ? S_src[S_bidx] : 1'b0;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_mcnt   <= 2'd0;
            S_slot   <= 6'd0;
            S_sl     <= 16'd0;
            S_sr     <= 16'd0;
            O_bclk   <= 1'b0;
            O_lrck   <= 1'b0;
            O_adclrc <= 1'b0;
            O_dacdat <= 1'b0;
            O_tick   <= 1'b0;
        end
        else begin
            S_mcnt <= S_mcnt + 2'd1;
            O_tick <= 1'b0;

            if (S_mcnt == 2'd0) begin
                //----------------------------------------- BCLK falling edge
                O_bclk   <= 1'b0;
                S_slot   <= S_nslot;
                O_lrck   <= S_nslot[5];
                O_adclrc <= S_nslot[5];
                O_dacdat <= I_en ? S_bitv : 1'b0;

                if (S_nslot == 6'd0) begin
                    S_sl   <= I_sample;
                    S_sr   <= I_sample;
                    O_tick <= 1'b1;
                end
            end
            else if (S_mcnt == 2'd2) begin
                //----------------------------------------- BCLK rising edge
                O_bclk <= 1'b1;
            end
        end
    end

endmodule

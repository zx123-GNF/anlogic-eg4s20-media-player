# FPGA 安路一题代码（EG4S20 HDMI 多媒体播放器）

2026 年安路赛道第 1 题（选题一：EG4S20 HDMI 多媒体播放）赛程期间写的**全部阶段代码**，
加上**全部调试日志**，按里程碑分目录存放。

- 板卡：**AC208** = AC201-EG4S20 底板 + AC601 核心板，芯片 **EG4S20BG256**（19600 LUT / 64 BRAM9K / 29 DSP / 4 PLL，片内 8 MB SDRAM 硬宏）
- 工具：**TangDynasty TD Release 2026.1 SP2**（本机装在 `E:\bin`，license `E:\license\Anlogic.lic`）
- 最终版：`代码/m6_final`（M6 改名而来，顶层 `m6_top`），bitstream 已固化在 SPI 配置 Flash 里，断电重启自启动

## 目录

```
代码/
  m0_hdmi/         M0  首版 HDMI 640x480 彩条（显示屏不认 480p）
  m0_720p/         M0  1280x720 彩条探测（屏认可，定下 720p 输出方案）
  m1_sdram_fb/     M1  片内 SDRAM 双页帧缓存 -> HDMI
  m2_sd_tf_bmp/    M2  TF 卡 SPI + FAT32 只读 + BMP 解码，640x480 画布（早期链路）
  m2_720p/         M2  同一条链路重建到 1280x720 画布（640x480 居中）
  m3_interact/     M3  按键切图 / 长按暂停 / 3 s 轮播 / 数码管图号（640x480 链）
  m3_720p/         M3  交互重建到 720p 链
  m4_audio/        M4  WM8960 I2C 初始化 + I2S 1 kHz 正弦（640x480 链）
  m4_720p/         M4  M3 + 音频合并到 720p，耳机实测出声
  m5_video/        M5  M5V1 视频软解码 + 双页环形写 + HDMI 内嵌音频
  m6_final/        M6  照片 + 视频混排播放列表，SPI Flash 固化（最终版，原 m6_media 改名）
  tools/           PC 端工具：M5V1 编码器、BMP 生成、烧录、串口读取
  README.md        原始仓库 README（里程碑表、卡内容、命令都在里面）
调试日志/
  下载日志/         BitWriter 下载日志（bw_*.log），按时间命名
  构建日志/         TD 综合/布局布线日志（console_ci.log、td_*.log），每个工程 syn_1 / phy_1 各一份
  串口和烧录日志/    flash.ps1、read_uart.ps1 的运行记录
文档/
  阶段调试记录/     m0~m6 每阶段的调试报告与上板复盘（含 bug 证据、时序数字）
  使用说明/         板级手册要点、TD 工具链、示例工程架构调研、演示脚本
  设计规格/         赛题方案设计文档
```

每个工程目录的结构（原始仓库里就是这么放的，没有改动）：

```
<工程>/
  rtl/              自己写的 RTL + 厂商驱动（sd_spi/、sdram_ctrl_4p/、hdmi1.4b_transmitter_core/）
  al_ip/            TD 生成的 PLL/IP 包装
  sim/              与 RTL 等价的 Python 行为模型（脱离板子验证用）
  <工程>.al         TD 工程文件，双击/打开即可综合
  <工程>.adc        引脚约束
  timing.sdc        时序约束
  build.ps1         命令行一键综合（两次 TD run：syn_1 -> phy_1）
  make_proj_files.ps1  .al 工程文件生成脚本
  run_flow.tcl      TD 的 Tcl 流程包装（把 TD 不可靠的退出码变成真返回值）
```

## 各阶段一览

| 阶段 | 工程 | 输出 | 板上验证 |
|---|---|---|---|
| M0 探测 | `m0_hdmi` | 640x480 彩条 | 屏报 "not support" |
| M0-720p | `m0_720p` | 1280x720 彩条 | 通过，定下 720p 方案 |
| M1 | `m1_sdram_fb` | SDRAM 双页帧缓存 + 渐变测试图 | 通过 |
| M2 | `m2_720p` | TF 卡 BMP 播放器 | 通过 |
| M3 | `m3_720p` | M2 + 数码管 + 短按换图 + 长按暂停 + 3 s 轮播 | 通过 |
| M4 | `m4_720p` | M3 + WM8960 音频 | 通过（耳机 1 kHz 出声） |
| M5 | `m5_video` | M5V1 视频解码 + HDMI 内嵌音频 | 通过（画面 + 显示器原声） |
| M6 最终版 | `m6_final` | 照片 + 视频混排播放列表、浏览、数码管总数+序号、SPI Flash 固化 | 通过（2026-10-28，断电自启动） |

早期的 `m0_hdmi`、`m2_sd_tf_bmp`、`m3_interact`、`m4_audio` 是 640x480 版本，
在确认显示屏只收 720p 之后，同一条链路被重建到 720p（`m2_720p`、`m3_720p`、`m4_720p`）。
两条支线都留在包里，方便看出方案是怎么迁移的。

## 注释是怎么处理的

按要求做了减注释：**只动注释文本，代码一行没改**。

- 保留：文件头（banner + 文件名 + 一句话用途）、分节标题（`// ---- sector engine ----`、
  `// state encoding`、全大写标题）、70 字以内的单行短标注、NOTE/WARNING/注意/实测 这类说明
- 删除：段落式解释（多行散文）、行尾注释、没有标题的纯装饰分隔线
- 统计：171 个源文件，代码+脚本 44128 行 -> 37382 行（-15.3%），
  注释行 8144 行 -> 1275 行（-84.3%）
- 校验：每个被处理过的文件都比对过「去掉注释后的 token 流」，处理前后完全一致
  （426 个文件复核，0 处差异）；Verilog 的 begin/end、module、always 计数前后相同，
  Python 再过一遍 `ast.parse`，PowerShell 用解析器扫一遍语法
- 没有动的：调试模块的代码（`m*_dbg_uart.v`、`m*_dbg_vid.v`、`$display` 调试分支、
  `O_dbg_*` 端口全部保留，只是它们的注释按同一规则删了）、测试模型、厂商 RTL、
  `al_ip` 生成文件、Python 的 docstring（运行时可读的用法说明，不算注释）、
  以及 `调试日志/` 下的全部日志文件（一个字节没改）

也就是说：正文里的说法在 `文档/阶段调试记录/` 能找到完整来龙去脉，
被删掉的注释内容并没有丢，只是没有塞回代码里。

## 综合与烧录

用 TD GUI 打开工程最省事：`代码/m6_final/m6_final.al` -> Run（综合 + 布局布线 + 生成 bit）。

命令行方式（和赛程里用的一样）：

```powershell
cd 代码\m6_final
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
# 输出 m6_final_Runs\phy_1\m6_final.bit，末尾打印 SWNS/HWNS 和资源占用
```

注意两点：

1. `build.ps1` 把两次 TD run 的输出写到工程目录下的 `m6_final_Runs\{syn_1,phy_1}`，
   包里没有带 `_Runs` 目录（几十 MB 的中间文件），TD 打开 `.al` 时会自己建。
2. `make_proj_files.ps1` 里的 `$root` 写死成赛程时的工作路径
   `E:\fpga-2026\dsh_code\proj\<工程>`，它只用来重新生成 `.al`，`.al` 已经带在包里，
   正常情况下用不到；真要重生成就把 `$root` 改成当前路径。

烧录：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File 代码\tools\flash.ps1 -Proj m6_final
# 写配置 Flash（断电保持）：-Mode program_spi     校验：-Mode verify_spi
# 需要 AL-LINK 驱动，见 代码\tools\install_al_link_driver.ps1
```

上板注意（踩过的坑）：

- 显示器只认 720p 及以上，480p 会直接报 "not support"
- 每次重新配置 FPGA 之后要拔插一次 HDMI，否则屏可能不开机（HPD/EDID 没有做，时序固定）
- TF 卡不支持热插拔，换卡要重新上电
- SPI 数据时钟用 12.5 MHz；25 MHz 下 MISO 采样余量不够，读出来的数据会错
- `-Mode program_spi` 大约 87 s，`verify_spi` 大约 28 s，之后断电重启约 2 s 出第一张照片

## 卡上的内容（M6）

```
IMG0001.BMP ~ IMG0005.BMP   640x480 24bit BMP，5 张
VID0.M5V                    M5 阶段的演示片（编号 0）
VID0005.M5V                 579 帧，19.7 MB
VID0006.M5V                 371 帧，13.0 MB
```

文件名规则 `IMG<1~4 位数字>.BMP` / `VID<1~4 位数字>.M5V`，按数字升序排进播放列表，
同号时图片排在视频前面。所以顺序是 IMG0001..IMG0005、VID0、VID0005、VID0006 共 8 项，
数码管左边显示总数 `08`、右边显示当前序号。

## 日志怎么看

- `调试日志/构建日志/<工程>/<工程>_Runs_{syn_1,phy_1}/console_ci.log`
  是每次 TD 流程的完整输出；`td_*.log` 是 TD 自己的日志。时间戳最近的几个对应最终那一版。
- 工程改名前后的两套都留着：`m6_media/` 是改名前的构建记录（当时的 M6 就是最终设计），
  `m6_final/` 是改名后重新综合布局布线的一遍，两次资源占用一致
  （5302 LUT / 6282 REG / 33 BRAM / 2 DSP，SWNS +0.102 ns、HWNS +0.003 ns，bit 629 635 B）。
- `调试日志/下载日志/` 是 BitWriter 的下载记录，能看到每次烧写用了哪种模式、结果是否成功。
- `调试日志/串口和烧录日志/` 是 `flash.ps1`、`read_uart.ps1` 每次运行的输出，
  查上板问题时先看 `uart-last.log`。

这些日志是原始文件，一个字节都没改；里面的时间戳、失败记录（比如时序违例、`err=4`、
bitstream 校验失败）都保留着。

## 说明

代码是赛程中的真实状态，没有为了好看去重构：所以会看到 `m5_*` 和 `m6_*` 两个模块体系并存、
`m6_fat.v` 里保留着调试分支、`sim/` 下是和 RTL 对照用的模型。
最终版以 `代码/m6_final`（顶层 `m6_top`）为准，其余目录是它之前的阶段。

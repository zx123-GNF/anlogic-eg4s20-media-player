//=============================================================================
//  m5_top.v  --  M2 milestone : TF card (SPI) -> FAT32 -> 640x480 24 bit BMP
//                 -> SDRAM page B -> page swap -> HDMI

`timescale 1ns / 10ps

module m5_top #(
    parameter DEBUG_STREAM = 0,
    parameter DEBUG_AUDIO  = 0,
    parameter DEBUG_ERR    = 0,
    parameter HDMI_TONE    = 0
) (
    input  wire clk,
    input  wire rst_n,
    input  wire key0_n,
    input  wire key1_n,

    output wire SD_CLK,
    output wire SD_MOSI,
    input  wire SD_MISO,
    output wire SD_CS,

    output wire [3:0] led,

    output wire uart_tx,

    output wire SEG7_SCLK,
    output wire SEG7_RCLK,
    output wire SEG7_DIO,

    output wire I2S_MCLK,
    output wire I2S_BCLK,
    output wire I2S_DACLRC,
    output wire I2S_DACDAT,
    output wire I2C_SCL,
    inout  wire I2C_SDA,

    output wire O_tmds_ch0_p,
    output wire O_tmds_ch1_p,
    output wire O_tmds_ch2_p,
    output wire O_tmds_clk_p
);

    localparam HTOTAL  = 1650;
    localparam HSA     = 40;
    localparam HFP     = 110;
    localparam HBP     = 220;
    localparam HACTIVE = 1280;

    localparam VTOTAL  = 750;
    localparam VSA     = 5;
    localparam VFP     = 5;
    localparam VBP     = 20;
    localparam VACTIVE = 720;

    localparam [20:0] PAGE_A_BASE = 21'h000000;
    localparam [20:0] PAGE_B_BASE = 21'h04B000;
    localparam [20:0] PAGE_A_END  = 21'h04B000;
    localparam [20:0] PAGE_END    = 21'h096000;

    localparam PAGE_W = 640;
    localparam PAGE_H = 480;

    wire S_pixel_clk;
    wire S_serial_clk;
    wire S_pll_lock;
    wire S_clk100_unused;

    pll_hdmi_720p u_pll (
        .refclk  (clk),
        .reset   (1'b0),
        .extlock (S_pll_lock),
        .clk0_out(S_clk100_unused),
        .clk1_out(S_pixel_clk),
        .clk2_out(S_serial_clk)
    );

    // KEY2 is asynchronous -> sample it on the 50 MHz reference clock
    reg [1:0] S_key_n_sync;
    always @(posedge clk) begin
        S_key_n_sync <= {S_key_n_sync[0], rst_n};
    end

    wire S_rst_n_async = S_pll_lock & S_key_n_sync[1];

    reg [1:0] S_rst50_sync;
    always @(posedge clk or negedge S_rst_n_async) begin
        if (!S_rst_n_async)
            S_rst50_sync <= 2'b00;
        else
            S_rst50_sync <= {S_rst50_sync[0], 1'b1};
    end
    wire S_rst_50 = ~S_rst50_sync[1];

    // pixel domain (25 MHz)
    reg [1:0] S_rst_pix_sync;
    always @(posedge S_pixel_clk or negedge S_rst_n_async) begin
        if (!S_rst_n_async)
            S_rst_pix_sync <= 2'b00;
        else
            S_rst_pix_sync <= {S_rst_pix_sync[0], 1'b1};
    end
    wire S_rst_pixel = ~S_rst_pix_sync[1];

    // serial domain (125 MHz)
    reg [1:0] S_rst_ser_sync;
    always @(posedge S_serial_clk or negedge S_rst_n_async) begin
        if (!S_rst_n_async)
            S_rst_ser_sync <= 2'b00;
        else
            S_rst_ser_sync <= {S_rst_ser_sync[0], 1'b1};
    end
    wire S_rst_serial = ~S_rst_ser_sync[1];

    wire        S_sdram_clk;
    wire        S_sdr_clk;
    wire [10:0] S_sa;
    wire [1:0]  S_ba;
    wire [1:0]  S_cs_n;
    wire        S_cke, S_ras_n, S_cas_n, S_we_n;
    wire [31:0] S_dq;
    wire [3:0]  S_dqm;
    wire        S_test_oe_unused;

    wire [31:0] S_wr_data;
    wire        S_wr;
    wire        S_wr_full;
    wire        S_wr_load;
    wire [20:0] S_wr_addr;
    wire [31:0] S_rd1_data;
    wire [31:0] S_rd2_data;
    wire        S_rd1_re, S_rd2_re;
    wire        S_rd1_empty, S_rd2_empty;

    reg [15:0] S_sdram_rst_cnt;
    always @(posedge S_pixel_clk or negedge S_rst_n_async) begin
        if (!S_rst_n_async)
            S_sdram_rst_cnt <= 16'd0;
        else if (!S_sdram_rst_cnt[15])
            S_sdram_rst_cnt <= S_sdram_rst_cnt + 16'd1;
    end
    wire S_sdram_rst_n_pix = S_sdram_rst_cnt[15];

    reg [1:0] S_sdram_rst_sync;
    always @(posedge S_sdram_clk or negedge S_sdram_rst_n_pix) begin
        if (!S_sdram_rst_n_pix)
            S_sdram_rst_sync <= 2'b00;
        else
            S_sdram_rst_sync <= {S_sdram_rst_sync[0], 1'b1};
    end
    wire S_sdram_ready = S_sdram_rst_sync[1];
    wire S_rst_sdram   = ~S_sdram_ready;

    Sdram_Control_4Port u_sdram (
        .REF_CLK      (clk),
        .RESET_N      (~S_rst_sdram),
        .CLK          (S_sdram_clk),

        // FIFO write side 1 : image page writer (one row per WR1_LOAD)
        .WR1_DATA     (S_wr_data),
        .WR1          (S_wr),
        .WR1_ADDR     (S_wr_addr),
        .WR1_MAX_ADDR (PAGE_END),
        .WR1_LENGTH   (9'h80),
        .WR1_LOAD     (S_wr_load),
        .WR1_CLK      (S_sdram_clk),
        .WR1_FULL     (S_wr_full),
        .WR1_USE      (),

        // FIFO write side 2 : unused
        .WR2_DATA     (32'd0),
        .WR2          (1'b0),
        .WR2_ADDR     (21'd0),
        .WR2_MAX_ADDR (21'd0),
        .WR2_LENGTH   (9'd0),
        .WR2_LOAD     (1'b0),
        .WR2_CLK      (1'b0),
        .WR2_FULL     (),
        .WR2_USE      (),

        // FIFO read side 1 : page A
        .RD1_DATA     (S_rd1_data),
        .RD1          (S_rd1_re),
        .RD1_ADDR     (PAGE_A_BASE),
        .RD1_MAX_ADDR (PAGE_A_END),
        .RD1_LENGTH   (9'h80),
        .RD1_LOAD     (1'b0),
        .RD1_CLK      (S_pixel_clk),
        .RD1_EMPTY    (S_rd1_empty),
        .RD1_USE      (),

        // FIFO read side 2 : page B
        .RD2_DATA     (S_rd2_data),
        .RD2          (S_rd2_re),
        .RD2_ADDR     (PAGE_B_BASE),
        .RD2_MAX_ADDR (PAGE_END),
        .RD2_LENGTH   (9'h80),
        .RD2_LOAD     (1'b0),
        .RD2_CLK      (S_pixel_clk),
        .RD2_EMPTY    (S_rd2_empty),
        .RD2_USE      (),

        // SDRAM side (stays inside the die)
        .SA           (S_sa),
        .BA           (S_ba),
        .CS_N         (S_cs_n),
        .CKE          (S_cke),
        .RAS_N        (S_ras_n),
        .CAS_N        (S_cas_n),
        .WE_N         (S_we_n),
        .DQ           (S_dq),
        .DQM          (S_dqm),
        .SDR_CLK      (S_sdr_clk),
        .test_oe      (S_test_oe_unused)
    );

    sdram_ip u_sdram_mem (
        .clk   (S_sdr_clk),
        .ras_n (S_ras_n),
        .cas_n (S_cas_n),
        .we_n  (S_we_n),
        .addr  (S_sa),
        .ba    (S_ba),
        .dq    (S_dq),
        .cs_n  (S_cs_n[0]),
        .dm0   (S_dqm[0]),
        .dm1   (S_dqm[1]),
        .dm2   (S_dqm[2]),
        .dm3   (S_dqm[3]),
        .cke   (S_cke)
    );

    wire        S_axis_user, S_axis_valid, S_axis_last;
    wire [23:0] S_axis_data;
    wire        S_axis_ready;

    wire        S_ready_tog, S_ready_page, S_disp_page;
    wire        S_key_next_tog, S_key_prev_tog;
    wire        S_st_has_img;
    wire        S_paused;
    wire        S_ready_pulse;

    m5_video_src720 #(
        .HTOTAL  (HTOTAL),  .HSA     (HSA),   .HBP     (HBP),
        .HFP     (HFP),     .HACTIVE (HACTIVE),
        .VTOTAL  (VTOTAL),  .VSA     (VSA),   .VBP     (VBP),
        .VFP     (VFP),     .VACTIVE (VACTIVE)
    ) u_video_src (
        .I_clk          (S_pixel_clk),
        .I_rst          (S_rst_pixel),
        .I_key0_n       (key0_n),
        .I_key1_n       (key1_n),
        .I_sdram_ready  (S_sdram_ready),
        .I_rd1_data     (S_rd1_data),
        .I_rd2_data     (S_rd2_data),
        .O_rd1_re       (S_rd1_re),
        .O_rd2_re       (S_rd2_re),
        .I_ready_tog    (S_ready_tog),
        .I_ready_page   (S_ready_page),
        .I_st_has_img   (S_st_has_img),
        .O_disp_page    (S_disp_page),
        .O_key_next_tog (S_key_next_tog),
        .O_key_prev_tog (S_key_prev_tog),
        .O_paused       (S_paused),
        .O_ready_pulse  (S_ready_pulse),
        .O_video_user   (S_axis_user),
        .O_video_valid  (S_axis_valid),
        .O_video_last   (S_axis_last),
        .O_video_data   (S_axis_data)
    );

    wire        S_vdec_busy;
    wire [15:0] S_frame_cnt;
    wire [5:0]  S_vdec_st, S_str_st;
    wire [2:0]  S_vdec_err, S_str_err;
    wire        S_str_mounted, S_vfile_eof;
    wire [31:0] S_dbg_clus, S_dbg_lba, S_dbg_byt;
    wire        S_vbyte_valid, S_vbyte_ready;
    wire [7:0]  S_vbyte;
    wire        S_aud_we;
    wire [15:0] S_aud_data;
    wire [8:0]  S_stream_ram_addr;
    wire [15:0] S_dbg_bps;
    wire [3:0]  S_dbg_type;
    wire [5:0]  S_dbg_fail;
    wire [7:0]  S_dbg_spc, S_dbg_nfat;
    wire [15:0] S_dbg_rsvd;
    wire [31:0] S_dbg_data, S_dbg_fat, S_dbg_first, S_dbg_size;
    wire [8:0]  S_dbg_secin;
    wire [31:0] S_dbg_chk;
    wire [31:0] S_dbg_mclus, S_dbg_flba, S_dbg_fat0;
    wire [7:0]  S_dbg_b0;

    // video decoder bring-up counters (m5_vdec)
    wire [31:0] S_dbg_vbyt, S_dbg_vpx, S_dbg_vlen, S_dbg_endv;
    wire [31:0] S_dbg_hdrb, S_dbg_raw32, S_dbg_rawh;
    wire [15:0] S_dbg_audn;

    wire        S_sd_init, S_sd_start, S_sd_busy, S_sd_done, S_sd_err;
    wire [31:0] S_sd_lba;
    wire [8:0]  S_buf_addr;
    wire [7:0]  S_buf_dout;

    assign S_buf_addr = S_stream_ram_addr;

    m5_sd_sec u_sd (
        .I_clk      (S_sdram_clk),
        .I_rst      (S_rst_sdram),
        .I_init     (S_sd_init),
        .I_start    (S_sd_start),
        .I_lba      (S_sd_lba),
        .O_busy     (S_sd_busy),
        .O_done     (S_sd_done),
        .O_err      (S_sd_err),
        .I_ram_addr (S_buf_addr),
        .O_ram_dout (S_buf_dout),
        .O_sd_clk   (SD_CLK),
        .O_sd_mosi  (SD_MOSI),
        .O_sd_cs_n  (SD_CS),
        .I_sd_miso  (SD_MISO)
    );

    m5_stream u_stream (
        .I_clk         (S_sdram_clk),
        .I_rst         (S_rst_sdram),
        .I_sdram_ready (S_sdram_ready),

        .O_sd_init     (S_sd_init),
        .O_sd_start    (S_sd_start),
        .O_sd_lba      (S_sd_lba),
        .I_sd_busy     (S_sd_busy),
        .I_sd_done     (S_sd_done),
        .I_sd_err      (S_sd_err),

        .O_ram_addr    (S_stream_ram_addr),
        .I_ram_dout    (S_buf_dout),

        .O_byte_valid  (S_vbyte_valid),
        .O_byte        (S_vbyte),
        .I_byte_ready  (S_vbyte_ready),

        .O_mounted     (S_str_mounted),
        .O_err         (S_str_err),
        .O_st          (S_str_st),
        .O_dbg_clus    (S_dbg_clus),
        .O_dbg_lba     (S_dbg_lba),
        .O_dbg_byt     (S_dbg_byt),
        .O_eof         (S_vfile_eof),

        .O_dbg_bps     (S_dbg_bps),
        .O_dbg_type    (S_dbg_type),
        .O_dbg_fail    (S_dbg_fail),
        .O_dbg_spc     (S_dbg_spc),
        .O_dbg_nfat    (S_dbg_nfat),
        .O_dbg_rsvd    (S_dbg_rsvd),
        .O_dbg_data    (S_dbg_data),
        .O_dbg_fat     (S_dbg_fat),
        .O_dbg_first   (S_dbg_first),
        .O_dbg_size    (S_dbg_size),
        .O_dbg_secin   (S_dbg_secin),
        .O_dbg_mclus   (S_dbg_mclus),
        .O_dbg_flba    (S_dbg_flba),
        .O_dbg_fat0    (S_dbg_fat0),
        .O_dbg_b0      (S_dbg_b0),
        .O_dbg_chk     (S_dbg_chk)
    );

    m5_vdec #(
        .CLK_HZ (100_000_000),
        .FPS    (15)
    ) u_vdec (
        .I_clk         (S_sdram_clk),
        .I_rst         (S_rst_sdram),
        .I_sdram_ready (S_sdram_ready),

        .I_byte_valid  (S_vbyte_valid),
        .I_byte        (S_vbyte),
        .O_byte_ready  (S_vbyte_ready),
        .I_eof         (S_vfile_eof),

        .O_wr          (S_wr),
        .O_wr_data     (S_wr_data),
        .I_wr_full     (S_wr_full),
        .O_wr_load     (S_wr_load),
        .O_wr_addr     (S_wr_addr),

        .O_ready_tog   (S_ready_tog),
        .O_ready_page  (S_ready_page),

        .O_busy        (S_vdec_busy),
        .O_frame_cnt   (S_frame_cnt),
        .O_st          (S_vdec_st),
        .O_err         (S_vdec_err),

        .O_aud_we      (S_aud_we),
        .O_aud_data    (S_aud_data),

        .O_dbg_vbyt    (S_dbg_vbyt),
        .O_dbg_px      (S_dbg_vpx),
        .O_dbg_audn    (S_dbg_audn),
        .O_dbg_len     (S_dbg_vlen),
        .O_dbg_endv    (S_dbg_endv),
        .O_dbg_hdrb    (S_dbg_hdrb),
        .O_dbg_raw32   (S_dbg_raw32),
        .O_dbg_rawh    (S_dbg_rawh)
    );

    wire [31:0] S_hex_data;
    wire [7:0]  S_hex_sw;
    wire        S_hex_mode;
    wire [7:0]  S_hex_seg, S_hex_sel;

    reg [31:0] S_aud_act;
    always @(posedge S_sdram_clk) begin
        if (S_rst_sdram)
            S_aud_act <= 32'd0;
        else if (S_aud_we && (S_aud_data[15:8] != 8'h00))
            S_aud_act <= S_aud_act + 32'd1;
    end

    wire [2:0]  S_dbg_er_or = S_vdec_err | S_str_err;

    reg [26:0] S_dbg_ptmr;
    always @(posedge clk) begin
        if (~S_rst_n_async) S_dbg_ptmr <= 27'd0;
        else                S_dbg_ptmr <= S_dbg_ptmr + 27'd1;
    end
    wire [1:0]  S_dbg_ppage = S_dbg_ptmr[26:25];
    reg  [31:0] S_hex_dbg;
    always @(*) begin
        case (S_dbg_ppage)
            2'd0:    S_hex_dbg = {S_i2s_wcnt[31:16], S_i2s_unf[15:0]};
            2'd1:    S_hex_dbg = {S_hdmi_unf[15:0], S_aud_act[31:16]};
            2'd2:    S_hex_dbg = {S_i2s_lvl, S_hdmi_lvl,
                                   S_str_mounted, S_dbg_er_or};
            default: S_hex_dbg = {S_i2s_ovf[15:0], S_hdmi_ovf[15:0]};
        endcase
    end

    m5_hex_status u_hex_status (
        .I_clk       (clk),
        .I_rst       (~S_rst_n_async),
        .I_mounted   (S_str_mounted),
        .I_err       (S_vdec_err | S_str_err),
        .I_count     (5'd0),
        .I_index     (S_frame_cnt[4:0]),
        .I_busy      (S_vdec_busy),
        .I_paused    (1'b0),

        .I_dbg_en    (DEBUG_STREAM),
        .I_dbg_data  (S_hex_dbg),
        .O_disp_data (S_hex_data),
        .O_sw        (S_hex_sw),
        .O_mode      (S_hex_mode)
    );

    HEX8 u_hex8 (
        .clk       (clk),
        .rst_n     (S_rst_n_async),
        .en        (1'b1),
        .switch    (1'b1),
        .mode      (S_hex_mode),
        .sw        (S_hex_sw),
        .disp_data (S_hex_data),
        .sel       (S_hex_sel),
        .seg       (S_hex_seg)
    );

    HC595_Driver u_hc595 (
        .Clk        (clk),
        .Rst_n      (S_rst_n_async),
        .Data       ({S_hex_seg, S_hex_sel}),
        .S_EN       (1'b1),
        .SEG7_SCLK  (SEG7_SCLK),
        .SEG7_RCLK  (SEG7_RCLK),
        .SEG7_DIO   (SEG7_DIO)
    );
    wire S_dbg_tx;

    m5_dbg_vid #(
        .CLK_HZ (50_000_000),
        .BAUD   (115200)
    ) u_dbg (
        .I_clk        (clk),
        .I_rst        (~S_rst_n_async),
        .I_sst        (S_str_st),
        .I_vst        (S_vdec_st),
        .I_err        (S_vdec_err | S_str_err),
        .I_mnt        (S_str_mounted),
        .I_frm        (S_frame_cnt),
        .I_vbyt       (S_dbg_vbyt),
        .I_vpx        (S_dbg_vpx),
        .I_audn       (S_dbg_audn),
        .I_len        (S_dbg_vlen),
        .I_byt        (S_dbg_byt),
        .I_chk        (S_dbg_chk),
        .I_first      (S_dbg_first),
        .I_lba        (S_dbg_lba),
        .I_size       (S_dbg_size),
        .I_eof        (S_vfile_eof),
        .O_uart_tx    (S_dbg_tx)
    );

    // I2C scanner debug build: its ASCII report replaces the FAT dumper
    wire S_scan_busy, S_scan_done, S_scan_any, S_scan_codec, S_scan_uart;

    assign uart_tx = (DEBUG_AUDIO == 2) ? S_scan_uart : S_dbg_tx;

    assign S_st_has_img = S_str_mounted;

    wire S_mclk;
    wire S_audio_lock;

    pll_m5_audio u_pll_audio (
        .refclk  (clk),
        .reset   (1'b0),
        .extlock (S_audio_lock),
        .clk0_out(S_mclk)
    );

    wire S_rst_n_audio = S_rst_n_async & S_audio_lock;

    // 50 MHz domain (I2C)
    reg [1:0] S_rst_i2c_sync;
    always @(posedge clk or negedge S_rst_n_audio) begin
        if (!S_rst_n_audio)
            S_rst_i2c_sync <= 2'b00;
        else
            S_rst_i2c_sync <= {S_rst_i2c_sync[0], 1'b1};
    end
    wire S_rst_i2c = ~S_rst_i2c_sync[1];

    // MCLK domain (tone + I2S)
    reg [1:0] S_rst_mclk_sync;
    always @(posedge S_mclk or negedge S_rst_n_audio) begin
        if (!S_rst_n_audio)
            S_rst_mclk_sync <= 2'b00;
        else
            S_rst_mclk_sync <= {S_rst_mclk_sync[0], 1'b1};
    end
    wire S_rst_mclk = ~S_rst_mclk_sync[1];

    wire       S_init_busy, S_init_done, S_init_ok, S_init_nack;
    wire [4:0] S_init_idx;
    wire       S_scl_o, S_sda_o, S_sda_oe, S_sda_i;

    generate
    if (DEBUG_AUDIO == 2) begin : g_i2c_scan
        m5_i2c_scan #(
            .CLK_HZ (50_000_000),
            .BAUD   (115200)
        ) u_i2c_scan (
            .I_clk       (clk),
            .I_rst       (S_rst_50),
            .O_scl       (S_scl_o),
            .O_sda_o     (S_sda_o),
            .O_sda_oe    (S_sda_oe),
            .I_sda_i     (S_sda_i),
            .O_uart_tx   (S_scan_uart),
            .O_busy      (S_scan_busy),
            .O_done      (S_scan_done),
            .O_any_ack   (S_scan_any),
            .O_codec_ack (S_scan_codec)
        );
        // the initialiser is not built, so its status is constant
        assign S_init_busy = 1'b0;
        assign S_init_done = 1'b0;
        assign S_init_ok   = 1'b0;
        assign S_init_nack = 1'b0;
        assign S_init_idx  = 5'd0;
    end else begin : g_i2c_init
        m5_i2s_init_dev u_i2c_init (
            .I_clk     (clk),
            .I_rst     (S_rst_i2c),
            .O_busy    (S_init_busy),
            .O_done    (S_init_done),
            .O_ok      (S_init_ok),
            .O_nack_err(S_init_nack),
            .O_index   (S_init_idx),
            .O_scl     (S_scl_o),
            .O_sda_o   (S_sda_o),
            .O_sda_oe  (S_sda_oe),
            .I_sda_i   (S_sda_i)
        );
        assign S_scan_busy  = 1'b0;
        assign S_scan_done  = 1'b0;
        assign S_scan_any   = 1'b0;
        assign S_scan_codec = 1'b0;
        assign S_scan_uart  = 1'b0;
    end
    endgenerate

    assign I2C_SCL = S_scl_o;
    assign I2C_SDA = S_sda_oe ? S_sda_o : 1'bz;
    assign S_sda_i = I2C_SDA;

    reg [1:0] S_ok_sync;
    always @(posedge S_mclk or negedge S_rst_n_audio) begin
        if (!S_rst_n_audio)
            S_ok_sync <= 2'b00;
        else
            S_ok_sync <= {S_ok_sync[0], S_init_ok};
    end
    wire S_aud_en = S_ok_sync[1];

    wire [15:0] S_aud_sample;
    wire        S_aud_tick;

    // bring-up counters of the two audio FIFOs
    wire [31:0] S_i2s_wcnt, S_i2s_ovf, S_i2s_unf;
    wire [13:0] S_i2s_lvl;
    wire [31:0] S_hdmi_wcnt, S_hdmi_ovf, S_hdmi_unf;
    wire [13:0] S_hdmi_lvl;

    m5_aud_fifo u_aud_fifo (
        .I_wclk   (S_sdram_clk),
        .I_wrst   (S_rst_sdram),
        .I_we     (S_aud_we),
        .I_wdata  (S_aud_data),
        .O_wlevel (S_i2s_lvl),
        .O_wr_cnt (S_i2s_wcnt),
        .O_ovf_cnt(S_i2s_ovf),

        .I_rclk   (S_mclk),
        .I_rrst   (S_rst_mclk),
        .I_rd     (S_aud_tick),
        .O_rdata  (S_aud_sample),
        .O_unf_cnt(S_i2s_unf)
    );

    m5_i2s_tx u_i2s_tx (
        .I_clk   (S_mclk),
        .I_rst   (S_rst_mclk),
        .I_en    (S_aud_en),
        .I_sample(S_aud_sample),
        .O_tick  (S_aud_tick),
        .O_mclk  (I2S_MCLK),
        .O_bclk  (I2S_BCLK),
        .O_lrck  (I2S_DACLRC),
        .O_dacdat(I2S_DACDAT)
    );

    reg [3:0] S_led;
    always @(posedge S_sdram_clk) begin
        if (S_rst_sdram)
            S_led <= 4'b0000;
        else
            S_led <= {(S_hdmi_lvl > 14'd256),
                      ((S_vdec_err | S_str_err) != 3'd0),
                      S_vdec_busy, S_str_mounted};
    end
    assign led = (DEBUG_AUDIO == 2) ? {~S_scan_done, ~S_scan_any, ~S_scan_codec, ~S_scan_busy}
               : DEBUG_AUDIO        ? {~S_audio_lock, ~S_init_ok, ~S_init_nack, ~S_init_busy}
               : DEBUG_ERR          ? {1'b1, (S_str_err != 3'd0), (S_vdec_err != 3'd0), S_str_mounted}
               :                      ~S_led;

    reg  [31:0] S_aph;
    wire [32:0] S_aph_nx = {1'b0, S_aph} + 33'd2811250;

    always @(posedge S_pixel_clk) begin
        if (S_rst_pixel) S_aph <= 32'd0;
        else             S_aph <= S_aph_nx[31:0];
    end
    wire S_aud48 = S_aph_nx[32];

    wire [15:0] S_hdmi_sample;
    wire        S_acr_valid;
    wire [19:0] S_acr_cts, S_acr_n;

    m5_aud_fifo #(
        .AW (12)
    ) u_hdmi_aud_fifo (
        .I_wclk   (S_sdram_clk),
        .I_wrst   (S_rst_sdram),
        .I_we     (S_aud_we),
        .I_wdata  (S_aud_data),
        .O_wlevel (S_hdmi_lvl),
        .O_wr_cnt (S_hdmi_wcnt),
        .O_ovf_cnt(S_hdmi_ovf),

        .I_rclk   (S_pixel_clk),
        .I_rrst   (S_rst_pixel),
        .I_rd     (S_aud48),
        .O_rdata  (S_hdmi_sample),
        .O_unf_cnt(S_hdmi_unf)
    );

    wire [15:0] S_hdmi_tone;
    m5_sine_tone u_hdmi_tone (
        .I_clk   (S_pixel_clk),
        .I_rst   (S_rst_pixel),
        .I_tick  (S_aud48),
        .I_en    (1'b1),
        .O_sample(S_hdmi_tone)
    );
    wire [15:0] S_hdmi_src = HDMI_TONE ? S_hdmi_tone : S_hdmi_sample;

    m5_audio_acr #(
        .ACR_N (6144)
    ) u_hdmi_acr (
        .I_clk         (S_pixel_clk),
        .I_rst         (S_rst_pixel),
        .I_audio_valid (S_aud48),
        .O_acr_valid   (S_acr_valid),
        .O_acr_cts     (S_acr_cts),
        .O_acr_n       (S_acr_n)
    );

    wire [9:0] S_ch0_tmds_data;
    wire [9:0] S_ch1_tmds_data;
    wire [9:0] S_ch2_tmds_data;
    wire [9:0] S_clk_tmds_data;

    wire S_ddc_scl_unused;
    wire S_ddc_sda_unused;
    wire S_edid_valid_unused;
    wire [7:0] S_edid_data_unused;
    wire S_video_locked_unused;

    hdmi_1_4b_transmitter_core_wrapper #(
        .DEVICE            ("EG"),
        .HTOTAL            (HTOTAL),
        .HSA               (HSA),
        .HFP               (HFP),
        .HBP               (HBP),
        .HACTIVE           (HACTIVE),
        .VTOTAL            (VTOTAL),
        .VSA               (VSA),
        .VFP               (VFP),
        .VBP               (VBP),
        .VACTIVE           (VACTIVE),
        .VIDEO_VIC         (4),
        .VIDEO_TPG         ("Disable"),
        .VIDEO_FORMAT      ("RGB"),
        .AUDIO_SAMPLE_RATE ("48K"),
        .IIC_SCL_DIV       (125)
    ) u_hdmi_core (
        .I_pixel_clk        (S_pixel_clk),
        .I_rst              (S_rst_pixel),
        .I_edid_read_trig   (1'b0),
        .O_edid_read_valid  (S_edid_valid_unused),
        .O_edid_read_data   (S_edid_data_unused),
        .I_axis_s_user      (S_axis_user),
        .I_axis_s_valid     (S_axis_valid),
        .I_axis_s_last      (S_axis_last),
        .I_axis_s_data      (S_axis_data),
        .O_axis_s_ready     (S_axis_ready),
        .I_audio_valid      (S_aud48),
        .I_audio_left_data  ({S_hdmi_src, 8'h00}),
        .I_audio_right_data ({S_hdmi_src, 8'h00}),
        .I_acr_valid        (S_acr_valid),
        .I_acr_cts          (S_acr_cts),
        .I_acr_n            (S_acr_n),
        .O_video_locked     (S_video_locked_unused),
        .O_ddc_scl          (S_ddc_scl_unused),
        .IO_ddc_sda         (S_ddc_sda_unused),
        .O_ch0_tmds_data    (S_ch0_tmds_data),
        .O_ch1_tmds_data    (S_ch1_tmds_data),
        .O_ch2_tmds_data    (S_ch2_tmds_data),
        .O_clk_tmds_data    (S_clk_tmds_data)
    );

    hdmi_phy_wrapper #(
        .DEVICE ("EG")
    ) u_hdmi_phy (
        .I_pixel_clk        (S_pixel_clk),
        .I_serial_clk       (S_serial_clk),
        .I_rst              (S_rst_serial),
        .I_tmds_channel_0   (S_ch0_tmds_data),
        .I_tmds_channel_1   (S_ch1_tmds_data),
        .I_tmds_channel_2   (S_ch2_tmds_data),
        .I_tmds_channel_clk (S_clk_tmds_data),
        .O_tmds_ch0_p       (O_tmds_ch0_p),
        .O_tmds_ch1_p       (O_tmds_ch1_p),
        .O_tmds_ch2_p       (O_tmds_ch2_p),
        .O_tmds_clk_p       (O_tmds_clk_p)
    );

endmodule

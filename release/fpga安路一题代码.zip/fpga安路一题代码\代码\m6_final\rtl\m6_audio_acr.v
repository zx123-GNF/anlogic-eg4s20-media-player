//=============================================================================
//  m6_audio_acr.v  --  HDMI Audio Clock Regeneration packet generator

`timescale 1ns / 10ps

module m6_audio_acr #(
    parameter integer ACR_N = 6144
) (
    input  wire        I_clk,
    input  wire        I_rst,
    input  wire        I_audio_valid,

    output reg         O_acr_valid,
    output reg  [19:0] O_acr_cts,
    output reg  [19:0] O_acr_n
);

    localparam integer AUDIO_DIV = ACR_N >> 7;

    reg  [7:0]  S_div;
    reg  [19:0] S_cts;

    wire S_acr = I_audio_valid && (S_div == (AUDIO_DIV - 1));

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_div       <= 8'd0;
            S_cts       <= 20'd0;
            O_acr_valid <= 1'b0;
            O_acr_cts   <= 20'd0;
            O_acr_n     <= 20'd0;
        end else begin
            if (I_audio_valid)
                S_div <= S_acr ? 8'd0 : (S_div + 8'd1);
            S_cts <= S_acr ? 20'd0 : (S_cts + 20'd1);

            O_acr_valid <= S_acr;
            O_acr_cts   <= S_acr ? (S_cts + 20'd1) : 20'd0;
            O_acr_n     <= S_acr ? ACR_N[19:0]     : 20'd0;
        end
    end

endmodule

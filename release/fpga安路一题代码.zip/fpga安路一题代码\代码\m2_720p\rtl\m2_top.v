//=============================================================================
//  m2_top.v  --  M2 milestone : TF card (SPI) -> FAT32 -> 640x480 24 bit BMP
//                 -> SDRAM page B -> page swap -> HDMI

`timescale 1ns / 10ps

module m2_top #(
    parameter DEBUG_ERR = 1
) (
    input  wire clk,
    input  wire rst_n,
    input  wire key0_n,
    input  wire key1_n,

    output wire SD_CLK,
    output wire SD_MOSI,
    input  wire SD_MISO,
    output wire SD_CS,

    output wire [3:0] led,

    output wire uart_tx,

    output wire O_tmds_ch0_p,
    output wire O_tmds_ch1_p,
    output wire O_tmds_ch2_p,
    output wire O_tmds_clk_p
);

    localparam HTOTAL  = 1650;
    localparam HSA     = 40;
    localparam HFP     = 110;
    localparam HBP     = 220;
    localparam HACTIVE = 1280;

    localparam VTOTAL  = 750;
    localparam VSA     = 5;
    localparam VFP     = 5;
    localparam VBP     = 20;
    localparam VACTIVE = 720;

    localparam [20:0] PAGE_A_BASE = 21'h000000;
    localparam [20:0] PAGE_B_BASE = 21'h04B000;
    localparam [20:0] PAGE_A_END  = 21'h04B000;
    localparam [20:0] PAGE_END    = 21'h096000;

    localparam PAGE_W = 640;
    localparam PAGE_H = 480;

    wire S_pixel_clk;
    wire S_serial_clk;
    wire S_pll_lock;
    wire S_clk100_unused;

    pll_hdmi_720p u_pll (
        .refclk  (clk),
        .reset   (1'b0),
        .extlock (S_pll_lock),
        .clk0_out(S_clk100_unused),
        .clk1_out(S_pixel_clk),
        .clk2_out(S_serial_clk)
    );

    // KEY2 is asynchronous -> sample it on the 50 MHz reference clock
    reg [1:0] S_key_n_sync;
    always @(posedge clk) begin
        S_key_n_sync <= {S_key_n_sync[0], rst_n};
    end

    wire S_rst_n_async = S_pll_lock & S_key_n_sync[1];

    // pixel domain (25 MHz)
    reg [1:0] S_rst_pix_sync;
    always @(posedge S_pixel_clk or negedge S_rst_n_async) begin
        if (!S_rst_n_async)
            S_rst_pix_sync <= 2'b00;
        else
            S_rst_pix_sync <= {S_rst_pix_sync[0], 1'b1};
    end
    wire S_rst_pixel = ~S_rst_pix_sync[1];

    // serial domain (125 MHz)
    reg [1:0] S_rst_ser_sync;
    always @(posedge S_serial_clk or negedge S_rst_n_async) begin
        if (!S_rst_n_async)
            S_rst_ser_sync <= 2'b00;
        else
            S_rst_ser_sync <= {S_rst_ser_sync[0], 1'b1};
    end
    wire S_rst_serial = ~S_rst_ser_sync[1];

    wire        S_sdram_clk;
    wire        S_sdr_clk;
    wire [10:0] S_sa;
    wire [1:0]  S_ba;
    wire [1:0]  S_cs_n;
    wire        S_cke, S_ras_n, S_cas_n, S_we_n;
    wire [31:0] S_dq;
    wire [3:0]  S_dqm;
    wire        S_test_oe_unused;

    wire [31:0] S_wr_data;
    wire        S_wr;
    wire        S_wr_full;
    wire        S_wr_load;
    wire [20:0] S_wr_addr;
    wire [31:0] S_rd1_data;
    wire [31:0] S_rd2_data;
    wire        S_rd1_re, S_rd2_re;
    wire        S_rd1_empty, S_rd2_empty;

    reg [15:0] S_sdram_rst_cnt;
    always @(posedge S_pixel_clk or negedge S_rst_n_async) begin
        if (!S_rst_n_async)
            S_sdram_rst_cnt <= 16'd0;
        else if (!S_sdram_rst_cnt[15])
            S_sdram_rst_cnt <= S_sdram_rst_cnt + 16'd1;
    end
    wire S_sdram_rst_n_pix = S_sdram_rst_cnt[15];

    reg [1:0] S_sdram_rst_sync;
    always @(posedge S_sdram_clk or negedge S_sdram_rst_n_pix) begin
        if (!S_sdram_rst_n_pix)
            S_sdram_rst_sync <= 2'b00;
        else
            S_sdram_rst_sync <= {S_sdram_rst_sync[0], 1'b1};
    end
    wire S_sdram_ready = S_sdram_rst_sync[1];
    wire S_rst_sdram   = ~S_sdram_ready;

    Sdram_Control_4Port u_sdram (
        .REF_CLK      (clk),
        .RESET_N      (~S_rst_sdram),
        .CLK          (S_sdram_clk),

        // FIFO write side 1 : image page writer (one row per WR1_LOAD)
        .WR1_DATA     (S_wr_data),
        .WR1          (S_wr),
        .WR1_ADDR     (S_wr_addr),
        .WR1_MAX_ADDR (PAGE_END),
        .WR1_LENGTH   (9'h80),
        .WR1_LOAD     (S_wr_load),
        .WR1_CLK      (S_sdram_clk),
        .WR1_FULL     (S_wr_full),
        .WR1_USE      (),

        // FIFO write side 2 : unused
        .WR2_DATA     (32'd0),
        .WR2          (1'b0),
        .WR2_ADDR     (21'd0),
        .WR2_MAX_ADDR (21'd0),
        .WR2_LENGTH   (9'd0),
        .WR2_LOAD     (1'b0),
        .WR2_CLK      (1'b0),
        .WR2_FULL     (),
        .WR2_USE      (),

        // FIFO read side 1 : page A
        .RD1_DATA     (S_rd1_data),
        .RD1          (S_rd1_re),
        .RD1_ADDR     (PAGE_A_BASE),
        .RD1_MAX_ADDR (PAGE_A_END),
        .RD1_LENGTH   (9'h80),
        .RD1_LOAD     (1'b0),
        .RD1_CLK      (S_pixel_clk),
        .RD1_EMPTY    (S_rd1_empty),
        .RD1_USE      (),

        // FIFO read side 2 : page B
        .RD2_DATA     (S_rd2_data),
        .RD2          (S_rd2_re),
        .RD2_ADDR     (PAGE_B_BASE),
        .RD2_MAX_ADDR (PAGE_END),
        .RD2_LENGTH   (9'h80),
        .RD2_LOAD     (1'b0),
        .RD2_CLK      (S_pixel_clk),
        .RD2_EMPTY    (S_rd2_empty),
        .RD2_USE      (),

        // SDRAM side (stays inside the die)
        .SA           (S_sa),
        .BA           (S_ba),
        .CS_N         (S_cs_n),
        .CKE          (S_cke),
        .RAS_N        (S_ras_n),
        .CAS_N        (S_cas_n),
        .WE_N         (S_we_n),
        .DQ           (S_dq),
        .DQM          (S_dqm),
        .SDR_CLK      (S_sdr_clk),
        .test_oe      (S_test_oe_unused)
    );

    sdram_ip u_sdram_mem (
        .clk   (S_sdr_clk),
        .ras_n (S_ras_n),
        .cas_n (S_cas_n),
        .we_n  (S_we_n),
        .addr  (S_sa),
        .ba    (S_ba),
        .dq    (S_dq),
        .cs_n  (S_cs_n[0]),
        .dm0   (S_dqm[0]),
        .dm1   (S_dqm[1]),
        .dm2   (S_dqm[2]),
        .dm3   (S_dqm[3]),
        .cke   (S_cke)
    );

    wire        S_axis_user, S_axis_valid, S_axis_last;
    wire [23:0] S_axis_data;
    wire        S_axis_ready;

    wire        S_ready_tog, S_ready_page, S_disp_page;
    wire        S_key_next_tog, S_key_prev_tog;

    m2_video_src720 #(
        .HTOTAL  (HTOTAL),  .HSA     (HSA),   .HBP     (HBP),
        .HFP     (HFP),     .HACTIVE (HACTIVE),
        .VTOTAL  (VTOTAL),  .VSA     (VSA),   .VBP     (VBP),
        .VFP     (VFP),     .VACTIVE (VACTIVE)
    ) u_video_src (
        .I_clk          (S_pixel_clk),
        .I_rst          (S_rst_pixel),
        .I_key0_n       (key0_n),
        .I_key1_n       (key1_n),
        .I_sdram_ready  (S_sdram_ready),
        .I_rd1_data     (S_rd1_data),
        .I_rd2_data     (S_rd2_data),
        .O_rd1_re       (S_rd1_re),
        .O_rd2_re       (S_rd2_re),
        .I_ready_tog    (S_ready_tog),
        .I_ready_page   (S_ready_page),
        .O_disp_page    (S_disp_page),
        .O_key_next_tog (S_key_next_tog),
        .O_key_prev_tog (S_key_prev_tog),
        .O_video_user   (S_axis_user),
        .O_video_valid  (S_axis_valid),
        .O_video_last   (S_axis_last),
        .O_video_data   (S_axis_data)
    );

    wire        S_pix_valid, S_pix_ready;
    wire [23:0] S_pix_data;

    wire        S_wr_start;
    wire        S_wr_page, S_wr_bup, S_wr_flush, S_wr_done, S_wr_busy;

    m2_page_wr #(
        .HACTIVE (PAGE_W),
        .VACTIVE (PAGE_H)
    ) u_wr (
        .I_clk         (S_sdram_clk),
        .I_rst         (S_rst_sdram),
        .I_start       (S_wr_start),
        .I_page        (S_wr_page),
        .I_bottom_up   (S_wr_bup),
        .I_pix_data    (S_pix_data),
        .I_pix_valid   (S_pix_valid),
        .O_pix_ready   (S_pix_ready),
        .I_flush       (S_wr_flush),
        .I_fifo_full   (S_wr_full),
        .O_wr          (S_wr),
        .O_wr_data     (S_wr_data),
        .O_load        (S_wr_load),
        .O_addr        (S_wr_addr),
        .O_busy        (S_wr_busy),
        .O_done        (S_wr_done)
    );

    wire        S_sd_init, S_sd_start, S_sd_busy, S_sd_done, S_sd_err;
    wire [31:0] S_sd_lba;
    wire [8:0]  S_buf_addr;
    wire [7:0]  S_buf_dout;

    m2_sd_sec u_sd (
        .I_clk      (S_sdram_clk),
        .I_rst      (S_rst_sdram),
        .I_init     (S_sd_init),
        .I_start    (S_sd_start),
        .I_lba      (S_sd_lba),
        .O_busy     (S_sd_busy),
        .O_done     (S_sd_done),
        .O_err      (S_sd_err),
        .I_ram_addr (S_buf_addr),
        .O_ram_dout (S_buf_dout),
        .O_sd_clk   (SD_CLK),
        .O_sd_mosi  (SD_MOSI),
        .O_sd_cs_n  (SD_CS),
        .I_sd_miso  (SD_MISO)
    );

    wire        S_bs_start, S_bs_done;
    wire [8:0]  S_bs_off, S_bs_addr;
    wire [5:0]  S_bs_cnt;
    wire [271:0] S_bs_val;

    wire        S_pp_start, S_pp_done;
    wire [8:0]  S_pp_off, S_pp_addr;
    wire [9:0]  S_pp_cnt;
    wire        S_pp_pv;
    wire [23:0] S_pp_pd;

    wire        S_buf_sel;

    assign S_buf_addr = S_buf_sel ? S_pp_addr : S_bs_addr;

    m2_byte_seq u_bs (
        .I_clk   (S_sdram_clk),
        .I_rst   (S_rst_sdram),
        .I_start (S_bs_start),
        .I_off   (S_bs_off),
        .I_cnt   (S_bs_cnt),
        .O_busy  (),
        .O_done  (S_bs_done),
        .O_addr  (S_bs_addr),
        .I_din   (S_buf_dout),
        .O_val   (S_bs_val)
    );

    m2_pix_pump u_pp (
        .I_clk       (S_sdram_clk),
        .I_rst       (S_rst_sdram),
        .I_start     (S_pp_start),
        .I_off       (S_pp_off),
        .I_cnt       (S_pp_cnt),
        .O_busy      (),
        .O_done      (S_pp_done),
        .O_addr      (S_pp_addr),
        .I_din       (S_buf_dout),
        .O_pix_valid (S_pp_pv),
        .O_pix_data  (S_pp_pd),
        .I_pix_ready (S_pix_ready)
    );

    wire S_fat_mounted;
    wire [2:0] S_fat_err;
    wire [4:0] S_fat_count, S_fat_index;
    wire [5:0] S_fat_st;
    wire [7:0] S_fat_ck;

    m2_fat_bmp u_fat (
        .I_clk         (S_sdram_clk),
        .I_rst         (S_rst_sdram),
        .I_sdram_ready (S_sdram_ready),

        .O_sd_init     (S_sd_init),
        .O_sd_start    (S_sd_start),
        .O_sd_lba      (S_sd_lba),
        .I_sd_busy     (S_sd_busy),
        .I_sd_done     (S_sd_done),
        .I_sd_err      (S_sd_err),

        .O_bs_start    (S_bs_start),
        .O_bs_off      (S_bs_off),
        .O_bs_cnt      (S_bs_cnt),
        .I_bs_done     (S_bs_done),
        .I_bs_val      (S_bs_val),

        .O_pp_start    (S_pp_start),
        .O_pp_off      (S_pp_off),
        .O_pp_cnt      (S_pp_cnt),
        .I_pp_done     (S_pp_done),
        .I_pp_pix_valid(S_pp_pv),
        .I_pp_pix_data (S_pp_pd),

        .O_pix_valid   (S_pix_valid),
        .O_pix_data    (S_pix_data),
        .I_pix_ready   (S_pix_ready),

        .O_wr_start    (S_wr_start),
        .O_wr_page     (S_wr_page),
        .O_wr_bottom_up(S_wr_bup),
        .O_wr_flush    (S_wr_flush),
        .I_wr_done     (S_wr_done),

        .I_disp_page   (S_disp_page),
        .O_ready_tog   (S_ready_tog),
        .O_ready_page  (S_ready_page),

        .I_key_next_tog(S_key_next_tog),
        .I_key_prev_tog(S_key_prev_tog),

        .O_mounted     (S_fat_mounted),
        .O_err         (S_fat_err),
        .O_count       (S_fat_count),
        .O_index       (S_fat_index),
        .O_buf_sel     (S_buf_sel),
        .O_dbg_st      (S_fat_st),
        .O_dbg_ck      (S_fat_ck)
    );

    wire S_dbg_tx;

    m2_dbg_uart u_dbg (
        .I_clk     (S_sdram_clk),
        .I_rst     (S_rst_sdram),
        .I_bs_done (S_bs_done),
        .I_off     (S_bs_off),
        .I_cnt     (S_bs_cnt),
        .I_st      (S_fat_st),
        .I_val     (S_bs_val),
        .I_live_st (S_fat_st),
        .I_live_err(S_fat_err),
        .I_live_ck (S_fat_ck),
        .O_uart_tx (S_dbg_tx)
    );

    assign uart_tx = S_dbg_tx;

    reg [3:0] S_led;
    always @(posedge S_sdram_clk) begin
        if (S_rst_sdram)
            S_led <= 4'b0000;
        else
            S_led <= {S_disp_page, (S_fat_err != 3'd0), S_wr_busy, S_fat_mounted};
    end
    assign led = DEBUG_ERR ? {1'b1, ~S_fat_err} : S_led;

    wire [9:0] S_ch0_tmds_data;
    wire [9:0] S_ch1_tmds_data;
    wire [9:0] S_ch2_tmds_data;
    wire [9:0] S_clk_tmds_data;

    wire S_ddc_scl_unused;
    wire S_ddc_sda_unused;
    wire S_edid_valid_unused;
    wire [7:0] S_edid_data_unused;
    wire S_video_locked_unused;

    hdmi_1_4b_transmitter_core_wrapper #(
        .DEVICE            ("EG"),
        .HTOTAL            (HTOTAL),
        .HSA               (HSA),
        .HFP               (HFP),
        .HBP               (HBP),
        .HACTIVE           (HACTIVE),
        .VTOTAL            (VTOTAL),
        .VSA               (VSA),
        .VFP               (VFP),
        .VBP               (VBP),
        .VACTIVE           (VACTIVE),
        .VIDEO_VIC         (4),
        .VIDEO_TPG         ("Disable"),
        .VIDEO_FORMAT      ("RGB"),
        .AUDIO_SAMPLE_RATE ("48K"),
        .IIC_SCL_DIV       (125)
    ) u_hdmi_core (
        .I_pixel_clk        (S_pixel_clk),
        .I_rst              (S_rst_pixel),
        .I_edid_read_trig   (1'b0),
        .O_edid_read_valid  (S_edid_valid_unused),
        .O_edid_read_data   (S_edid_data_unused),
        .I_axis_s_user      (S_axis_user),
        .I_axis_s_valid     (S_axis_valid),
        .I_axis_s_last      (S_axis_last),
        .I_axis_s_data      (S_axis_data),
        .O_axis_s_ready     (S_axis_ready),
        .I_audio_valid      (1'b0),
        .I_audio_left_data  (24'd0),
        .I_audio_right_data (24'd0),
        .I_acr_valid        (1'b0),
        .I_acr_cts          (20'd0),
        .I_acr_n            (20'd0),
        .O_video_locked     (S_video_locked_unused),
        .O_ddc_scl          (S_ddc_scl_unused),
        .IO_ddc_sda         (S_ddc_sda_unused),
        .O_ch0_tmds_data    (S_ch0_tmds_data),
        .O_ch1_tmds_data    (S_ch1_tmds_data),
        .O_ch2_tmds_data    (S_ch2_tmds_data),
        .O_clk_tmds_data    (S_clk_tmds_data)
    );

    hdmi_phy_wrapper #(
        .DEVICE ("EG")
    ) u_hdmi_phy (
        .I_pixel_clk        (S_pixel_clk),
        .I_serial_clk       (S_serial_clk),
        .I_rst              (S_rst_serial),
        .I_tmds_channel_0   (S_ch0_tmds_data),
        .I_tmds_channel_1   (S_ch1_tmds_data),
        .I_tmds_channel_2   (S_ch2_tmds_data),
        .I_tmds_channel_clk (S_clk_tmds_data),
        .O_tmds_ch0_p       (O_tmds_ch0_p),
        .O_tmds_ch1_p       (O_tmds_ch1_p),
        .O_tmds_ch2_p       (O_tmds_ch2_p),
        .O_tmds_clk_p       (O_tmds_clk_p)
    );

endmodule

//=============================================================================
//  m3_seg7.v
//  8 digit 7 segment scan / decode / content mux for the AC208 display

`timescale 1ns / 10ps

module m3_seg7 #(
    // 25 MHz / 25000 = 1 kHz digit scan -> 125 Hz refresh per digit
    parameter SCAN_DIV = 25000,
    parameter DIG_REV = 0
) (
    input  wire        I_clk,
    input  wire        I_rst,

    // status from the 100 MHz loader (quasi static, filtered here)
    input  wire        I_mounted,
    input  wire [2:0]  I_err,
    input  wire [4:0]  I_count,
    input  wire        I_busy,
    input  wire [4:0]  I_index,
    input  wire [15:0] I_key,

    // interaction status from m3_video_src (same clock domain)
    input  wire        I_paused,
    input  wire        I_ready_pulse,

    output reg  [7:0]  O_seg,
    output reg  [7:0]  O_sel,
    output reg         O_start
);

    reg [14:0] S_div;
    reg [2:0]  S_dig;
    reg [7:0]  S_blink;

    wire S_tick = (S_div == (SCAN_DIV - 1));

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_div   <= 15'd0;
            S_dig   <= 3'd0;
            S_blink <= 8'd0;
        end else begin
            S_div <= S_tick ? 15'd0 : (S_div + 15'd1);
            if (S_tick) begin
                S_dig   <= S_dig + 3'd1;
                S_blink <= S_blink + 8'd1;
            end
        end
    end

    wire [29:0] W_raw = {I_mounted, I_err, I_count, I_index, I_key};

    reg [29:0] S_raw_s1, S_raw_s2;
    reg [29:0] S_f_d1,  S_f_d2;
    reg [29:0] S_stat;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_raw_s1 <= 30'd0;
            S_raw_s2 <= 30'd0;
            S_f_d1   <= 30'd0;
            S_f_d2   <= 30'd0;
            S_stat   <= 30'd0;
        end else begin
            S_raw_s1 <= W_raw;
            S_raw_s2 <= S_raw_s1;
            if (S_tick) begin
                S_f_d1 <= S_raw_s2;
                S_f_d2 <= S_f_d1;
                if (S_f_d1 == S_f_d2)
                    S_stat <= S_f_d2;
            end
        end
    end

    wire [15:0] W_key   = S_stat[15:0];
    wire [4:0]  W_index = S_stat[20:16];
    wire [4:0]  W_count = S_stat[25:21];
    wire [2:0]  W_err   = S_stat[28:26];
    // carried for completeness; the display decision itself only needs err
    wire        W_mnt   = S_stat[29];

    wire [5:0]  W_idx1 = {1'b0, W_index} + 6'd1;
    wire [3:0]  W_i_lo = (W_idx1 >= 6'd10) ? (W_idx1[3:0] - 4'd10) : W_idx1[3:0];
    wire [3:0]  W_i_hi = (W_idx1 >= 6'd10) ? 4'd1 : 4'd0;
    wire [15:0] W_num  = (W_key != 16'hFFFF) ? W_key
                                             : {8'h00, W_i_hi, W_i_lo};

    reg [15:0] S_num;
    reg        S_have_num;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_num      <= 16'h0000;
            S_have_num <= 1'b0;
        end else if (I_ready_pulse) begin
            S_num      <= W_num;
            S_have_num <= 1'b1;
        end
    end

    wire [3:0] W_c_lo = (W_count >= 5'd10) ? (W_count[3:0] - 4'd10) : W_count[3:0];
    wire [3:0] W_c_hi = (W_count >= 5'd10) ? 4'd1 : 4'd0;

    wire        W_tok     = (!S_have_num) || (W_count == 5'd0) || (W_err == 3'd4);
    wire        W_tok_err = (W_err != 3'd0);
    wire [4:0]  W_t0      = W_tok_err ? {2'b00, W_err}          : 5'h0F;
    wire [4:0]  W_t1      = W_tok_err ? {1'b0, 4'hE}             : 5'h0F;

    wire [4:0] W_d0 = W_tok ? W_t0                    : {1'b0, S_num[3:0]};
    wire [4:0] W_d1 = W_tok ? W_t1                    : {1'b0, S_num[7:4]};
    wire [4:0] W_d2 = W_tok ? 5'h10                   : {1'b0, S_num[11:8]};
    wire [4:0] W_d3 = W_tok ? 5'h10                   : {1'b0, S_num[15:12]};
    wire [4:0] W_d4 = 5'h10;
    wire [4:0] W_d5 = 5'h10;
    wire [4:0] W_d6 = W_tok ? 5'h10                   : {1'b0, W_c_lo};
    wire [4:0] W_d7 = W_tok ? 5'h10                   : {1'b0, W_c_hi};

    reg [4:0] S_code;

    always @(*) begin
        case (S_dig)
            3'd0:    S_code = W_d0;
            3'd1:    S_code = W_d1;
            3'd2:    S_code = W_d2;
            3'd3:    S_code = W_d3;
            3'd4:    S_code = W_d4;
            3'd5:    S_code = W_d5;
            3'd6:    S_code = W_d6;
            3'd7:    S_code = W_d7;
            default: S_code = 5'h10;
        endcase
    end

    function [6:0] SEG7;
        input [3:0] v;
        begin
            case (v)
                4'h0:    SEG7 = 7'b1000000;
                4'h1:    SEG7 = 7'b1111001;
                4'h2:    SEG7 = 7'b0100100;
                4'h3:    SEG7 = 7'b0110000;
                4'h4:    SEG7 = 7'b0011001;
                4'h5:    SEG7 = 7'b0010010;
                4'h6:    SEG7 = 7'b0000010;
                4'h7:    SEG7 = 7'b1111000;
                4'h8:    SEG7 = 7'b0000000;
                4'h9:    SEG7 = 7'b0010000;
                4'hA:    SEG7 = 7'b0001000;
                4'hB:    SEG7 = 7'b0000011;
                4'hC:    SEG7 = 7'b1000110;
                4'hD:    SEG7 = 7'b0100001;
                4'hE:    SEG7 = 7'b0000110;
                4'hF:    SEG7 = 7'b0111111;
                default: SEG7 = 7'b1111111;
            endcase
        end
    endfunction

    // 100 MHz "loading" flag -> 2FF (single bit, no filter needed)
    reg [1:0] S_busy_sync;

    always @(posedge I_clk) begin
        if (I_rst)
            S_busy_sync <= 2'b00;
        else
            S_busy_sync <= {S_busy_sync[0], I_busy};
    end

    wire S_busy     = S_busy_sync[1];
    wire S_blank    = (I_paused & S_blink[7]) || S_code[4];
    wire S_dot_on   = (S_dig == 3'd0) && S_busy;
    wire [7:0] W_seg = S_blank ? 8'hFF : {~S_dot_on, SEG7(S_code[3:0])};
    wire [7:0] W_sel = (DIG_REV == 0) ? (8'b0000_0001 << S_dig)
                                      : (8'b1000_0000 >> S_dig);

    always @(posedge I_clk) begin
        if (I_rst) begin
            O_seg   <= 8'hFF;
            O_sel   <= 8'h00;
            O_start <= 1'b0;
        end else begin
            O_start <= 1'b0;
            if (S_tick) begin
                O_seg   <= W_seg;
                O_sel   <= W_sel;
                O_start <= 1'b1;
            end
        end
    end

endmodule

//=============================================================================
//  m6_vstream.v  --  cluster chain block streamer for one video clip (100 MHz)

`timescale 1ns / 10ps

module m6_vstream (
    input  wire        I_clk,
    input  wire        I_rst,
    input  wire        I_sdram_ready,

    // ---- job parameters (latched on I_go) ----------------------------------
    input  wire        I_go,
    input  wire [31:0] I_clus,
    input  wire [31:0] I_size,
    input  wire [31:0] I_data_lba,
    input  wire [31:0] I_fat_lba,
    input  wire [7:0]  I_spc,
    input  wire [4:0]  I_log2spc,

    // ---- sector engine -----------------------------------------------------
    output reg         O_sd_start,
    output reg  [31:0] O_sd_lba,
    input  wire        I_sd_done,
    input  wire        I_sd_err,

    // ---- vendor sector RAM read port ---------------------------------------
    output reg  [8:0]  O_ram_addr,
    input  wire [7:0]  I_ram_dout,

    // ---- byte stream to the decoder ----------------------------------------
    output reg         O_byte_valid,
    output reg  [7:0]  O_byte,
    input  wire        I_byte_ready,

    // ---- status ------------------------------------------------------------
    output wire        O_busy,
    output reg  [2:0]  O_err,
    output reg  [5:0]  O_st,
    output reg  [31:0] O_byt,
    output reg         O_eof
);

    localparam [27:0] EOC = 28'h0FFFFFF8;

    localparam [5:0]
        T_IDLE   = 6'd0,
        T_ST_PRE = 6'd1,
        T_ST_PRE2= 6'd2,
        T_ST_GO  = 6'd3,
        T_ST_W   = 6'd4,
        T_COPY   = 6'd5,
        T_ST_BYTE= 6'd6,
        T_ST_NEXT= 6'd7,
        T_FAT_PRE= 6'd8,
        T_FAT_GO = 6'd9,
        T_FAT_W  = 6'd10,
        T_FAT_CL = 6'd11,
        T_FAT_CL2= 6'd14,
        T_LOOP   = 6'd12,
        T_ERR    = 6'd13;

    reg [5:0]  S_st;

    // job parameters
    reg [31:0] S_clus, S_clus_m2, S_first_clus;
    reg [31:0] S_size;
    reg [31:0] S_data_lba, S_fat_lba;
    reg [7:0]  S_spc;
    reg [4:0]  S_log2spc;

    // position inside the file
    reg [8:0]  S_sec_in;
    reg [31:0] S_bytes;

    // staged sector LBA
    reg [31:0] S_clus_off;
    reg [31:0] S_lba_r;
    reg [5:0]  S_after;

    wire [31:0] S_cl_off_w = S_clus_m2 * {23'd0, S_spc};
    wire [31:0] S_fat_sec  = S_fat_lba + {25'd0, S_clus[31:7]};
    wire [8:0]  S_fat_off  = {S_clus[6:0], 2'b00};

    wire [7:0] S_dbuf;
    reg  [8:0] S_frd;
    reg  [8:0] S_brd_s;
    reg        S_brd_sel;
    wire [8:0] S_brd = S_brd_sel ? S_brd_s : S_frd;
    reg  [8:0] S_caddr;
    reg        S_cwe;

    ram_dual_port_simple #(
        .data_width (8),
        .data_num   (512),
        .num_width  (9)
    ) u_secbuf (
        .douta (),
        .doutb (S_dbuf),
        .dina  (I_ram_dout),
        .addra (S_caddr),
        .addrb (S_brd),
        .wea   (S_cwe),
        .clka  (I_clk),
        .clkb  (I_clk)
    );

    localparam [1:0] C_IDLE = 2'd0, C_ADDR = 2'd1, C_W1 = 2'd2, C_W2 = 2'd3;

    reg [1:0] S_cst;
    reg [8:0] S_ci;
    reg       S_cgo;
    reg       S_cdone;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_cst      <= C_IDLE;
            S_ci       <= 9'd0;
            S_cwe      <= 1'b0;
            S_caddr    <= 9'd0;
            S_cdone    <= 1'b0;
            O_ram_addr <= 9'd0;
        end else begin
            S_cwe   <= 1'b0;
            S_cdone <= 1'b0;
            case (S_cst)
                C_IDLE: begin
                    if (S_cgo) begin
                        S_ci  <= 9'd0;
                        S_cst <= C_ADDR;
                    end
                end
                C_ADDR: begin
                    O_ram_addr <= S_ci;
                    S_cst      <= C_W1;
                end
                C_W1: S_cst <= C_W2;
                C_W2: begin
                    S_cwe   <= 1'b1;
                    S_caddr <= S_ci;
                    if (S_ci == 9'd511) begin
                        S_cdone <= 1'b1;
                        S_cst   <= C_IDLE;
                    end else begin
                        S_ci  <= S_ci + 9'd1;
                        S_cst <= C_ADDR;
                    end
                end
                default: S_cst <= C_IDLE;
            endcase
        end
    end

    localparam [1:0] F_IDLE = 2'd0, F_RD = 2'd1, F_CNT = 2'd2, F_CAP = 2'd3;

    reg [1:0]  S_fst;
    reg        S_fgo;
    reg [2:0]  S_fi;
    reg [7:0]  S_fbyte;
    reg [31:0] S_fval;
    reg        S_fdone;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_fst   <= F_IDLE;
            S_fdone <= 1'b0;
            S_fval  <= 32'd0;
            S_frd   <= 9'd0;
            S_fi    <= 3'd0;
            S_fbyte <= 8'd0;
        end else begin
            S_fdone <= 1'b0;
            case (S_fst)
                F_IDLE: begin
                    if (S_fgo) begin
                        S_frd  <= S_fat_off;
                        S_fi   <= 3'd0;
                        S_fval <= 32'd0;
                        S_fst  <= F_RD;
                    end
                end
                F_RD: S_fst <= F_CNT;
                F_CNT: begin
                    S_fbyte <= S_dbuf;
                    S_fst   <= F_CAP;
                end
                default: begin
                    S_fval <= S_fval | ({24'd0, S_fbyte} << {S_fi, 3'b000});
                    if ((S_fi + 3'd1) == 3'd4) begin
                        S_fdone <= 1'b1;
                        S_fst   <= F_IDLE;
                    end else begin
                        S_fi   <= S_fi + 3'd1;
                        S_frd  <= S_frd + 9'd1;
                        S_fst  <= F_RD;
                    end
                end
            endcase
        end
    end

    reg [1:0]  S_by_st;
    reg [8:0]  S_byte_ptr;

    assign O_busy = (S_st != T_IDLE) && (S_st != T_ERR);

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_st         <= T_IDLE;
            S_clus       <= 32'd0;
            S_clus_m2    <= 32'd0;
            S_first_clus <= 32'd0;
            S_size       <= 32'd0;
            S_data_lba   <= 32'd0;
            S_fat_lba    <= 32'd0;
            S_spc        <= 8'd1;
            S_log2spc    <= 5'd0;
            S_sec_in     <= 9'd0;
            S_bytes      <= 32'd0;
            S_clus_off   <= 32'd0;
            S_lba_r      <= 32'd0;
            S_after      <= T_ST_BYTE;
            S_byte_ptr   <= 9'd0;
            S_by_st      <= 2'd0;
            S_brd_sel    <= 1'b0;
            S_brd_s      <= 9'd0;
            S_cgo        <= 1'b0;
            S_fgo        <= 1'b0;
            O_sd_start   <= 1'b0;
            O_sd_lba     <= 32'd0;
            O_byte_valid <= 1'b0;
            O_byte       <= 8'd0;
            O_err        <= 3'd0;
            O_st         <= T_IDLE;
            O_byt        <= 32'd0;
            O_eof        <= 1'b0;
        end else begin
            O_sd_start <= 1'b0;
            S_cgo      <= 1'b0;
            S_fgo      <= 1'b0;
            O_eof      <= 1'b0;
            O_st       <= S_st;

            case (S_st)
            //------------------------------------------------- idle / start
            T_IDLE: begin
                O_byte_valid <= 1'b0;
                S_by_st      <= 2'd0;
                if (I_go && I_sdram_ready) begin
                    S_clus       <= I_clus;
                    S_clus_m2    <= I_clus - 32'd2;
                    S_first_clus <= I_clus;
                    S_size       <= I_size;
                    S_data_lba   <= I_data_lba;
                    S_fat_lba    <= I_fat_lba;
                    S_spc        <= (I_spc == 8'd0) ? 8'd1 : I_spc;
                    S_log2spc    <= I_log2spc;
                    S_sec_in     <= 9'd0;
                    S_bytes      <= 32'd0;
                    S_byte_ptr   <= 9'd0;
                    O_byt        <= 32'd0;
                    O_err        <= 3'd0;
                    S_st         <= T_ST_PRE;
                end
            end

            T_ST_PRE: begin
                S_clus_off <= S_cl_off_w;
                S_st       <= T_ST_PRE2;
            end

            T_ST_PRE2: begin
                S_lba_r <= S_data_lba + S_clus_off + {23'd0, S_sec_in};
                S_st    <= T_ST_GO;
            end

            T_ST_GO: begin
                O_sd_lba   <= S_lba_r;
                O_sd_start <= 1'b1;
                S_st       <= T_ST_W;
            end

            T_ST_W: begin
                if (I_sd_done) begin
                    S_cgo   <= 1'b1;
                    S_after <= T_ST_BYTE;
                    S_st    <= T_COPY;
                end else if (I_sd_err) begin
                    O_err <= 3'd5;
                    S_st  <= T_ERR;
                end
            end

            //------------------------------------------------- shared copy wait
            T_COPY: begin
                if (S_cdone) begin
                    S_brd_sel <= (S_after == T_ST_BYTE);
                    S_by_st   <= 2'd0;
                    S_st      <= S_after;
                end
            end

            //------------------------------------------------- byte handshake
            T_ST_BYTE: begin
                if (!O_byte_valid) begin
                    case (S_by_st)
                    2'd0: begin
                        S_brd_s <= S_byte_ptr;
                        S_by_st <= 2'd1;
                    end
                    2'd1: S_by_st <= 2'd2;
                    default: begin
                        O_byte       <= S_dbuf;
                        O_byte_valid <= 1'b1;
                        S_by_st      <= 2'd0;
                    end
                    endcase
                end else if (I_byte_ready) begin
                    O_byte_valid <= 1'b0;
                    O_byt        <= O_byt + 32'd1;
                    S_bytes      <= S_bytes + 32'd1;
                    if ((S_bytes + 32'd1) == S_size)
                        S_st <= T_LOOP;
                    else if (S_byte_ptr == 9'd511) begin
                        S_byte_ptr <= 9'd0;
                        S_st       <= T_ST_NEXT;
                    end else
                        S_byte_ptr <= S_byte_ptr + 9'd1;
                end
            end

            T_ST_NEXT: begin
                if (({1'b0, S_sec_in} + 10'd1) >= {2'd0, S_spc}) begin
                    S_sec_in <= 9'd0;
                    S_st     <= T_FAT_PRE;
                end else begin
                    S_sec_in <= S_sec_in + 9'd1;
                    S_st     <= T_ST_PRE;
                end
            end

            //------------------------------------------------- FAT chain
            T_FAT_PRE: begin
                S_lba_r <= S_fat_sec;
                S_st    <= T_FAT_GO;
            end

            T_FAT_GO: begin
                O_sd_lba   <= S_lba_r;
                O_sd_start <= 1'b1;
                S_st       <= T_FAT_W;
            end

            T_FAT_W: begin
                if (I_sd_done) begin
                    S_cgo   <= 1'b1;
                    S_after <= T_FAT_CL;
                    S_st    <= T_COPY;
                end else if (I_sd_err) begin
                    O_err <= 3'd6;
                    S_st  <= T_ERR;
                end
            end

            T_FAT_CL: begin
                S_brd_sel <= 1'b0;
                S_fgo     <= 1'b1;
                S_st      <= T_FAT_CL2;
            end

            T_FAT_CL2: begin
                if (S_fdone) begin
                    if (S_fval[27:0] >= EOC) begin
                        S_st <= T_LOOP;
                    end else begin
                        S_clus    <= S_fval;
                        S_clus_m2 <= S_fval - 32'd2;
                        S_st      <= T_ST_PRE;
                    end
                end
            end

            //------------------------------------------------- wrap to byte 0
            T_LOOP: begin
                O_eof     <= 1'b1;
                S_clus    <= S_first_clus;
                S_clus_m2 <= S_first_clus - 32'd2;
                S_sec_in  <= 9'd0;
                S_bytes   <= 32'd0;
                S_byte_ptr<= 9'd0;
                S_st      <= T_ST_PRE;
            end

            //------------------------------------------------- error
            T_ERR: begin
                O_byte_valid <= 1'b0;
                S_by_st      <= 2'd0;
                if (I_go) S_st <= T_IDLE;
            end

            default: S_st <= T_IDLE;
            endcase
        end
    end

endmodule

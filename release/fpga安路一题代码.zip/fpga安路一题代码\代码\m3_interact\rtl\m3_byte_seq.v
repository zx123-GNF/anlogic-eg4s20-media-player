//=============================================================================
//  m3_byte_seq.v
//  "read N bytes of the current 512 byte sector buffer into a register"

`timescale 1ns / 10ps

module m3_byte_seq (
    input  wire         I_clk,
    input  wire         I_rst,

    input  wire         I_start,
    input  wire [8:0]   I_off,
    input  wire [5:0]   I_cnt,
    output reg          O_busy,
    output reg          O_done,

    output reg  [8:0]   O_addr,
    input  wire [7:0]   I_din,

    output wire [271:0] O_val
);

    localparam S_IDLE = 2'd0;
    localparam S_PRE  = 2'd1;
    localparam S_RUN  = 2'd2;
    localparam S_DONE = 2'd3;

    reg [1:0]  S_st;
    reg [5:0]  S_idx;
    reg [5:0]  S_cnt;
    reg [7:0]  V [0:33];

    integer i;
    genvar  gi;

    generate
        for (gi = 0; gi < 34; gi = gi + 1) begin : G_pack
            assign O_val[8*gi + 7 : 8*gi] = V[gi];
        end
    endgenerate

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_st   <= S_IDLE;
            S_idx  <= 6'd0;
            S_cnt  <= 6'd1;
            O_busy <= 1'b0;
            O_done <= 1'b0;
            O_addr <= 9'd0;
            for (i = 0; i < 34; i = i + 1)
                V[i] <= 8'h00;
        end else begin
            O_done <= 1'b0;

            case (S_st)
                S_IDLE: begin
                    O_busy <= 1'b0;
                    if (I_start) begin
                        O_addr <= I_off;
                        S_cnt  <= (I_cnt == 6'd0) ? 6'd1 : I_cnt;
                        S_idx  <= 6'd0;
                        O_busy <= 1'b1;
                        S_st   <= S_PRE;
                    end
                end

                S_PRE: begin
                    S_st <= S_RUN;
                end

                S_RUN: begin
                    V[S_idx] <= I_din;
                    O_addr   <= O_addr + 9'd1;
                    S_idx    <= S_idx + 6'd1;
                    if (({1'b0, S_idx} + 7'd1) >= {1'b0, S_cnt}) begin
                        S_st <= S_DONE;
                    end
                end

                S_DONE: begin
                    O_done <= 1'b1;
                    O_busy <= 1'b0;
                    S_st   <= S_IDLE;
                end

                default: S_st <= S_IDLE;
            endcase
        end
    end

endmodule

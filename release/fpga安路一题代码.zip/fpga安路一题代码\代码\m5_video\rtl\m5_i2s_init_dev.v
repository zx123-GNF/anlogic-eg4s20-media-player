//=============================================================================
//  m5_i2s_init_dev.v  --  WM8960 I2C initialisation sequencer (M4)

`timescale 1ns / 10ps

module m5_i2s_init_dev #(
    parameter [19:0] POR_CLKS  = 20'd500_000,
    parameter [7:0]  DEV_ADDR  = 8'h34,
    parameter [1:0]  RETRY_MAX = 2'd3
)(
    input  wire I_clk,
    input  wire I_rst,

    output reg  O_busy,
    output reg  O_done,
    output reg  O_ok,
    output reg  O_nack_err,
    output reg  [4:0] O_index,

    // I2C pins (tri-state handled by the top level)
    output wire O_scl,
    output wire O_sda_o,
    output wire O_sda_oe,
    input  wire I_sda_i
);

    localparam [4:0] TABLE_LEN = 5'd13;

    localparam [2:0] S_POR   = 3'd0,
                     S_ISSUE = 3'd1,
                     S_WAIT  = 3'd2,
                     S_DELAY = 3'd3,
                     S_NEXT  = 3'd4,
                     S_OK    = 3'd5,
                     S_FAIL  = 3'd6;

    reg [2:0]  S_st;
    reg [4:0]  S_idx;
    reg [1:0]  S_retry;
    reg [19:0] S_por;
    reg [24:0] S_dly;
    reg [2:0]  S_dly_code;

    reg        S_start;
    reg  [6:0] S_reg;
    reg  [8:0] S_data;
    wire       S_busy;
    wire       S_done;
    wire       S_nack;

    wire [19:0] S_entry;
    wire [2:0]  S_entry_dly = S_entry[19:17];
    wire [7:0]  S_entry_reg = S_entry[16:9];
    wire [8:0]  S_entry_dat = S_entry[8:0];

    m5_wm8960_table u_table (
        .I_addr  (S_idx),
        .O_entry (S_entry)
    );

    m5_i2s_control u_ctrl (
        .I_clk   (I_clk),
        .I_rst   (I_rst),
        .I_start (S_start),
        .I_dev   (DEV_ADDR),
        .I_reg   (S_reg),
        .I_data  (S_data),
        .O_busy  (S_busy),
        .O_done  (S_done),
        .O_nack  (S_nack),
        .O_scl   (O_scl),
        .O_sda_o (O_sda_o),
        .O_sda_oe(O_sda_oe),
        .I_sda_i (I_sda_i)
    );

    reg [24:0] S_dly_end;
    always @(*) begin
        case (S_dly_code)
        3'd0: S_dly_end = 25'd0;
        3'd1: S_dly_end = 25'd50_000;
        3'd2: S_dly_end = 25'd500_000;
        3'd3: S_dly_end = 25'd5_000_000;
        3'd4: S_dly_end = 25'd25_000_000;
        default: S_dly_end = 25'd0;
        endcase
    end

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_st       <= S_POR;
            S_idx      <= 5'd0;
            S_retry    <= 2'd0;
            S_por      <= 20'd0;
            S_dly      <= 25'd0;
            S_dly_code <= 3'd0;
            S_start    <= 1'b0;
            S_reg      <= 7'd0;
            S_data     <= 9'd0;
            O_busy     <= 1'b0;
            O_done     <= 1'b0;
            O_ok       <= 1'b0;
            O_nack_err <= 1'b0;
            O_index    <= 5'd0;
        end
        else begin
            S_start <= 1'b0;
            O_done  <= 1'b0;

            case (S_st)
            //--------------------------------------------------- power on delay
            S_POR: begin
                O_busy <= 1'b1;
                if (S_por != POR_CLKS) begin
                    S_por <= S_por + 20'd1;
                end
                else begin
                    S_idx   <= 5'd0;
                    S_retry <= 2'd0;
                    S_st    <= S_ISSUE;
                end
            end
            //--------------------------------------------------- start one write
            S_ISSUE: begin
                O_busy     <= 1'b1;
                O_index    <= S_idx;
                S_reg      <= S_entry_reg[6:0];
                S_data     <= S_entry_dat;
                S_dly_code <= S_entry_dly;
                S_start    <= 1'b1;
                S_st       <= S_WAIT;
            end
            //--------------------------------------------------- wait for ACK
            S_WAIT: begin
                if (S_done) begin
                    if (S_nack) begin
                        if (S_retry == RETRY_MAX) begin
                            O_nack_err <= 1'b1;
                            O_ok       <= 1'b0;
                            S_st       <= S_FAIL;
                        end
                        else begin
                            S_retry <= S_retry + 2'd1;
                            S_st    <= S_ISSUE;
                        end
                    end
                    else begin
                        S_retry <= 2'd0;
                        S_dly   <= 25'd0;
                        S_st    <= S_DELAY;
                    end
                end
            end
            //--------------------------------------------------- post-write delay
            S_DELAY: begin
                if (S_dly >= S_dly_end) begin
                    S_st <= S_NEXT;
                end
                else begin
                    S_dly <= S_dly + 25'd1;
                end
            end
            //--------------------------------------------------- next register
            S_NEXT: begin
                if ((S_idx + 5'd1) >= TABLE_LEN) begin
                    O_ok <= 1'b1;
                    S_st <= S_OK;
                end
                else begin
                    S_idx <= S_idx + 5'd1;
                    S_st  <= S_ISSUE;
                end
            end
            //--------------------------------------------------- finished
            S_OK: begin
                O_busy <= 1'b0;
                O_done <= 1'b1;
            end
            S_FAIL: begin
                O_busy <= 1'b0;
                O_done <= 1'b1;
            end
            default: S_st <= S_POR;
            endcase
        end
    end

endmodule

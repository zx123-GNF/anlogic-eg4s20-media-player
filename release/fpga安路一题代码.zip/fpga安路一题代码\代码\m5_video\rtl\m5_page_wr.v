//=============================================================================
//  m5_page_wr.v
//  Frame-buffer page writer for M2:  307200 pixel words -> WR1 of

`timescale 1ns / 10ps

module m5_page_wr #(
    parameter HACTIVE = 640,
    parameter VACTIVE = 480,
    parameter DRAIN   = 4096
) (
    input  wire        I_clk,
    input  wire        I_rst,

    input  wire        I_start,
    input  wire        I_page,
    input  wire        I_bottom_up,

    input  wire [23:0] I_pix_data,
    input  wire        I_pix_valid,
    output wire        O_pix_ready,
    input  wire        I_flush,

    input  wire        I_fifo_full,

    output wire        O_wr,
    output wire [31:0] O_wr_data,
    output wire        O_load,
    output wire [20:0] O_addr,
    output wire        O_busy,
    output reg         O_done
);

    localparam PAGE_A_BASE = 21'h000000;
    localparam PAGE_B_BASE = 21'h04B000;

    localparam W_IDLE  = 3'd0;
    localparam W_LD0   = 3'd1;
    localparam W_LD1   = 3'd2;
    localparam W_ROW   = 3'd3;
    localparam W_DRAIN = 3'd4;
    localparam W_END   = 3'd5;

    reg [2:0]  S_st;
    reg        S_page;
    reg        S_bup;
    reg [8:0]  S_row;
    reg [9:0]  S_x;
    reg [12:0] S_dcnt;
    reg        S_last;
    reg        S_busy;
    reg        S_load;
    reg [20:0] S_addr;

    // row * 640 = row*512 + row*128
    wire [20:0] S_row_off  = {S_row, 9'b0} + {S_row, 7'b0};
    wire [20:0] S_row_base = (S_page ? PAGE_B_BASE : PAGE_A_BASE) + S_row_off;

    wire S_row_is_last = S_bup ? (S_row == 9'd0) : (S_row == (VACTIVE - 1));
    wire S_accept = (S_st == W_ROW) && (I_flush || I_pix_valid) && !I_fifo_full;

    assign O_wr      = S_accept;
    assign O_wr_data = I_flush ? 32'h00000000 : {8'h00, I_pix_data[23:0]};
    assign O_load    = S_load;
    assign O_addr    = S_addr;
    assign O_busy    = S_busy;
    assign O_pix_ready = (S_st == W_ROW) && !I_fifo_full && !I_flush;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_st    <= W_IDLE;
            S_page  <= 1'b0;
            S_bup   <= 1'b0;
            S_row   <= 9'd0;
            S_x     <= 10'd0;
            S_dcnt  <= 13'd0;
            S_last  <= 1'b0;
            S_busy  <= 1'b0;
            S_load  <= 1'b0;
            S_addr  <= 21'd0;
            O_done  <= 1'b0;
        end else begin
            O_done <= 1'b0;
            S_load <= 1'b0;

            case (S_st)
                W_IDLE: begin
                    S_busy <= 1'b0;
                    if (I_start && !S_busy) begin
                        S_page <= I_page;
                        S_bup  <= I_bottom_up;
                        S_row  <= I_bottom_up ? (VACTIVE - 1) : 9'd0;
                        S_x    <= 10'd0;
                        S_busy <= 1'b1;
                        S_st   <= W_LD0;
                    end
                end

                W_LD0: begin
                    S_addr <= S_row_base;
                    S_st   <= W_LD1;
                end

                W_LD1: begin
                    S_load <= 1'b1;
                    S_st   <= W_ROW;
                end

                W_ROW: begin
                    if (S_accept) begin
                        if (S_x == HACTIVE - 1) begin
                            S_x    <= 10'd0;
                            S_last <= S_row_is_last;
                            S_dcnt <= DRAIN;
                            S_st   <= W_DRAIN;
                            if (!S_row_is_last)
                                S_row <= S_bup ? (S_row - 9'd1) : (S_row + 9'd1);
                        end else begin
                            S_x <= S_x + 10'd1;
                        end
                    end
                end

                W_DRAIN: begin
                    S_dcnt <= S_dcnt - 13'd1;
                    if (S_dcnt == 13'd1) begin
                        if (S_last) S_st <= W_END;
                        else        S_st <= W_LD0;
                    end
                end

                W_END: begin
                    O_done <= 1'b1;
                    S_busy <= 1'b0;
                    S_st   <= W_IDLE;
                end

                default: S_st <= W_IDLE;
            endcase
        end
    end

endmodule

//=============================================================================
//  m3_hc595.v
//  16 bit serial shifter for the two cascaded 74HC595 of the AC208 7 segment

`timescale 1ns / 10ps

module m3_hc595 #(
    parameter DIV = 5
) (
    input  wire        I_clk,
    input  wire        I_rst,
    input  wire [15:0] I_data,
    input  wire        I_start,

    output reg         O_sclk,
    output reg         O_rclk,
    output reg         O_dio
);

    localparam H_IDLE  = 3'd0;
    localparam H_PRE   = 3'd1;
    localparam H_HI    = 3'd2;
    localparam H_LATCH = 3'd3;
    localparam H_LEND  = 3'd4;

    reg [2:0]  S_st;
    reg [15:0] S_sh;
    reg [3:0]  S_bit;
    reg [2:0]  S_div;

    wire S_step = (S_div == (DIV - 1));

    always @(posedge I_clk) begin
        if (I_rst)
            S_div <= 3'd0;
        else if (S_st == H_IDLE)
            S_div <= 3'd0;
        else
            S_div <= S_step ? 3'd0 : (S_div + 3'd1);
    end

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_st   <= H_IDLE;
            S_sh   <= 16'd0;
            S_bit  <= 4'd0;
            O_sclk <= 1'b0;
            O_rclk <= 1'b0;
            O_dio  <= 1'b0;
        end else begin
            case (S_st)
                H_IDLE: begin
                    O_sclk <= 1'b0;
                    O_rclk <= 1'b0;
                    if (I_start) begin
                        S_sh   <= I_data;
                        S_bit  <= 4'd15;
                        S_st   <= H_PRE;
                    end
                end

                H_PRE: if (S_step) begin
                    O_dio  <= S_sh[15];
                    O_sclk <= 1'b0;
                    S_sh   <= {S_sh[14:0], 1'b0};
                    S_st   <= H_HI;
                end

                H_HI: if (S_step) begin
                    O_sclk <= 1'b1;
                    if (S_bit == 4'd0) begin
                        S_st <= H_LATCH;
                    end else begin
                        S_bit <= S_bit - 4'd1;
                        S_st  <= H_PRE;
                    end
                end

                H_LATCH: if (S_step) begin
                    O_sclk <= 1'b0;
                    O_rclk <= 1'b1;
                    S_st   <= H_LEND;
                end

                H_LEND: if (S_step) begin
                    O_rclk <= 1'b0;
                    S_st   <= H_IDLE;
                end

                default: S_st <= H_IDLE;
            endcase
        end
    end

endmodule

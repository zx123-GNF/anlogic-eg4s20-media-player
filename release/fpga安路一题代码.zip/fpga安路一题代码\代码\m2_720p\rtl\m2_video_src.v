//=============================================================================
//  m2_video_src.v
//  M2 video source + frame-cache page controller (25 MHz pixel domain),

`timescale 1ns / 10ps

module m2_video_src #(
    parameter HTOTAL  = 800,
    parameter HSA     = 96,
    parameter HBP     = 48,
    parameter HFP     = 16,
    parameter HACTIVE = 640,

    parameter VTOTAL  = 525,
    parameter VSA     = 2,
    parameter VBP     = 33,
    parameter VFP     = 10,
    parameter VACTIVE = 480
) (
    input  wire        I_clk,
    input  wire        I_rst,

    input  wire        I_key0_n,
    input  wire        I_key1_n,
    input  wire        I_sdram_ready,

    input  wire [31:0] I_rd1_data,
    input  wire [31:0] I_rd2_data,
    output wire        O_rd1_re,
    output wire        O_rd2_re,

    input  wire        I_ready_tog,
    input  wire        I_ready_page,
    output wire        O_disp_page,

    output wire        O_key_next_tog,
    output wire        O_key_prev_tog,

    output reg         O_video_user,
    output reg         O_video_valid,
    output reg         O_video_last,
    output reg  [23:0] O_video_data
);

    localparam HBLANK = HTOTAL - HACTIVE;
    localparam VBLANK = VTOTAL - VACTIVE;

    reg [9:0] S_col_cnt;
    reg [9:0] S_line_cnt;

    always @(posedge I_clk) begin
        if (I_rst)
            S_col_cnt <= 10'd0;
        else if (S_col_cnt == HTOTAL - 1)
            S_col_cnt <= 10'd0;
        else
            S_col_cnt <= S_col_cnt + 10'd1;
    end

    always @(posedge I_clk) begin
        if (I_rst)
            S_line_cnt <= 10'd0;
        else if (S_col_cnt == HTOTAL - 1) begin
            if (S_line_cnt == VTOTAL - 1)
                S_line_cnt <= 10'd0;
            else
                S_line_cnt <= S_line_cnt + 10'd1;
        end
    end

    wire S_active = (S_line_cnt >= VBLANK) && (S_col_cnt >= HBLANK);
    wire S_vstart = (S_line_cnt == 10'd0) && (S_col_cnt == 10'd0);
    wire S_sof    = (S_line_cnt == VBLANK) && (S_col_cnt == HBLANK);
    wire S_eol    = S_active && (S_col_cnt == HTOTAL - 1);

    reg [3:0]  S_key_ss;
    reg [1:0]  S_key_stb, S_key_stb_d;
    reg [17:0] S_key_cnt [0:1];

    integer k;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_key_ss    <= 4'b1111;
            S_key_stb   <= 2'b11;
            S_key_stb_d <= 2'b11;
            for (k = 0; k < 2; k = k + 1)
                S_key_cnt[k] <= 18'd0;
        end else begin
            S_key_ss <= {S_key_ss[1:0], I_key1_n, I_key0_n};

            for (k = 0; k < 2; k = k + 1) begin
                if (S_key_ss[2+k] != S_key_stb[k]) begin
                    if (S_key_cnt[k] == 18'h3FFFF) begin
                        S_key_cnt[k] <= 18'd0;
                        S_key_stb[k] <= S_key_ss[2+k];
                    end else begin
                        S_key_cnt[k] <= S_key_cnt[k] + 18'd1;
                    end
                end else begin
                    S_key_cnt[k] <= 18'd0;
                end
            end

            S_key_stb_d <= S_key_stb;
        end
    end

    wire [1:0] S_key_press = S_key_stb_d & ~S_key_stb;

    reg S_kn_tog, S_kp_tog;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_kn_tog <= 1'b0;
            S_kp_tog <= 1'b0;
        end else begin
            if (S_key_press[0]) S_kn_tog <= ~S_kn_tog;
            if (S_key_press[1]) S_kp_tog <= ~S_kp_tog;
        end
    end

    assign O_key_next_tog = S_kn_tog;
    assign O_key_prev_tog = S_kp_tog;

    reg [2:0] S_ready_sync;
    reg [1:0] S_ready_pg_sync;
    reg [1:0] S_sdr_sync;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_ready_sync    <= 3'b000;
            S_ready_pg_sync <= 2'b00;
            S_sdr_sync      <= 2'b00;
        end else begin
            S_ready_sync    <= {S_ready_sync[1:0], I_ready_tog};
            S_ready_pg_sync <= {S_ready_pg_sync[0], I_ready_page};
            S_sdr_sync      <= {S_sdr_sync[0], I_sdram_ready};
        end
    end

    wire S_ready_pulse = S_ready_sync[1] ^ S_ready_sync[2];
    wire S_ready_pg    = S_ready_pg_sync[1];
    wire S_sdram_ok    = S_sdr_sync[1];

    reg [1:0] S_page_ok;
    reg       S_disp_page;
    reg       S_rd_en;
    reg       S_disp_en;
    reg       S_swap_pend;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_page_ok   <= 2'b00;
            S_disp_page <= 1'b0;
            S_rd_en     <= 1'b0;
            S_disp_en   <= 1'b0;
            S_swap_pend <= 1'b0;
        end else begin
            if (S_ready_pulse) begin
                S_page_ok[S_ready_pg] <= 1'b1;
                S_swap_pend           <= 1'b1;
            end else if (S_vstart) begin
                S_swap_pend <= 1'b0;
            end

            if (S_vstart && S_sdram_ok) begin
                if (S_swap_pend && S_page_ok[~S_disp_page]) begin
                    S_disp_page <= ~S_disp_page;
                    S_rd_en     <= 1'b1;
                end else if (S_page_ok[S_disp_page]) begin
                    S_rd_en     <= 1'b1;
                end
                S_disp_en <= S_rd_en;
            end
        end
    end

    assign O_disp_page = S_disp_page;

    wire [23:0] S_pix = S_disp_page ? I_rd2_data[23:0] : I_rd1_data[23:0];

    always @(posedge I_clk) begin
        if (I_rst) begin
            O_video_valid <= 1'b0;
            O_video_user  <= 1'b0;
            O_video_last  <= 1'b0;
            O_video_data  <= 24'd0;
        end else begin
            O_video_valid <= S_active;
            O_video_user  <= S_sof;
            O_video_last  <= S_eol;
            O_video_data  <= S_disp_en ? S_pix : 24'h000000;
        end
    end

    assign O_rd1_re = S_active && S_rd_en;
    assign O_rd2_re = S_active && S_rd_en;

endmodule

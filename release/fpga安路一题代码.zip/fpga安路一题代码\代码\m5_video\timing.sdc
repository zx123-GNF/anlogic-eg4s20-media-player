#-----------------------------------------------------------------------------
#  timing.sdc  --  m5_720p  (TF/FAT32/BMP player, 1280x720 HDMI output)

create_clock -name clk_50m -period 20.000 -waveform {0 10.000} [get_ports {clk}]

# 50 * 22 = 1100 MHz VCO reference on the (logic-unused) C0 tap
create_generated_clock -name clk_vco -source [get_ports {clk}] -multiply_by 22 \
    [get_pins {u_pll/pll_inst.clkc[0]}]

# 1100 / 15 = 73.333 MHz pixel clock
create_generated_clock -name pixel_clk -source [get_pins {u_pll/pll_inst.clkc[0]}] \
    -divide_by 15 \
    [get_pins {u_pll/pll_inst.clkc[1]}]

# 1100 / 3 = 366.667 MHz serial clock (10:1 TMDS with a DDR output)
create_generated_clock -name serial_clk -source [get_pins {u_pll/pll_inst.clkc[0]}] \
    -divide_by 3 \
    [get_pins {u_pll/pll_inst.clkc[2]}]

# 100.000 MHz SDRAM controller clock = 2 x 50.000 MHz
create_generated_clock -name sdram_clk \
    -source [get_ports {clk}] -multiply_by 2 \
    [get_pins {u_sdram/sdram_pll1/pll_inst.clkc[0]}]

create_generated_clock -name mclk_audio -source [get_ports {clk}] -divide_by 4 [get_pins {u_pll_audio/pll_inst.clkc[0]}]

set_clock_groups -exclusive -group [get_clocks {clk_50m}] -group [get_clocks {pixel_clk}] -group [get_clocks {serial_clk}] -group [get_clocks {sdram_clk}] -group [get_clocks {mclk_audio}]

//=============================================================================
//  m5_i2s_bit_shift.v  --  bit level I2C engine (byte / START / STOP / ACK)

`timescale 1ns / 10ps

module m5_i2s_bit_shift #(
    parameter SYS_CLOCK = 50_000_000,
    parameter SCL_CLOCK = 40_000
)(
    input  wire       I_clk,
    input  wire       I_rst,

    // command interface
    input  wire       I_go,
    input  wire [2:0] I_cmd,
    input  wire [7:0] I_tx_data,
    output reg  [7:0] O_rx_data,
    output reg        O_nack,
    output reg        O_done,

    // I2C pins (tri-state handled by the top level)
    output reg        O_scl,
    output reg        O_sda_o,
    output reg        O_sda_oe,
    input  wire       I_sda_i
);

    localparam [1:0] C_START = 2'd0,
                     C_WRITE = 2'd1,
                     C_STOP  = 2'd2;

    localparam [15:0] DIV = SYS_CLOCK / (SCL_CLOCK * 4);

    reg [15:0] S_div;
    reg        S_busy;
    wire       S_tick = (S_div == (DIV - 1));

    always @(posedge I_clk) begin
        if (I_rst || !S_busy)
            S_div <= 16'd0;
        else if (S_tick)
            S_div <= 16'd0;
        else
            S_div <= S_div + 16'd1;
    end

    reg [1:0] S_st;
    reg [1:0] S_ph;
    reg [3:0] S_bit;
    reg       S_hold;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_st      <= C_START;
            S_ph      <= 2'd0;
            S_bit     <= 4'd0;
            S_busy    <= 1'b0;
            S_hold    <= 1'b0;
            O_scl     <= 1'b1;
            O_sda_o   <= 1'b1;
            O_sda_oe  <= 1'b0;
            O_nack    <= 1'b0;
            O_done    <= 1'b0;
            O_rx_data <= 8'd0;
        end
        else begin
            O_done <= 1'b0;

            if (!S_busy) begin
                if (S_hold) begin
                    O_scl    <= 1'b0;
                    O_sda_oe <= 1'b0;
                    O_sda_o  <= 1'b1;
                end
                else begin
                    O_scl    <= 1'b1;
                    O_sda_oe <= 1'b0;
                    O_sda_o  <= 1'b1;
                end
                if (I_go) begin
                    S_busy <= 1'b1;
                    S_ph   <= 2'd0;
                    S_bit  <= 4'd0;
                    O_nack <= 1'b0;
                    S_hold <= 1'b0;
                    if (I_cmd[0])
                        S_st <= C_START;
                    else if (I_cmd[1])
                        S_st <= C_WRITE;
                    else if (I_cmd[2])
                        S_st <= C_STOP;
                    else begin
                        S_busy <= 1'b0;
                        O_done <= 1'b1;
                    end
                end
            end

            else if (S_tick) begin
                case (S_st)
                //----------------------------------------------------- START
                C_START: begin
                    case (S_ph)
                    2'd0: begin O_scl <= 1'b1; O_sda_oe <= 1'b1; O_sda_o <= 1'b1; end
                    2'd1: begin O_scl <= 1'b1; O_sda_o <= 1'b0; end
                    2'd2: begin O_scl <= 1'b0; end
                    2'd3: begin O_scl <= 1'b0; end
                    endcase
                    if (S_ph == 2'd3) begin
                        S_ph <= 2'd0;
                        S_st <= C_WRITE;
                    end
                    else
                        S_ph <= S_ph + 2'd1;
                end
                C_WRITE: begin
                    case (S_ph)
                    2'd0: begin
                        O_scl <= 1'b0;
                        if (S_bit == 4'd8) begin
                            O_sda_oe <= 1'b0;
                        end
                        else begin
                            O_sda_oe <= 1'b1;
                            O_sda_o  <= I_tx_data[3'd7 - S_bit[2:0]];
                        end
                    end
                    2'd1: begin O_scl <= 1'b1; end
                    2'd2: begin
                        O_scl <= 1'b1;
                        if (S_bit == 4'd8) begin
                            O_nack <= I_sda_i;
                        end
                    end
                    2'd3: begin O_scl <= 1'b0; end
                    endcase
                    if (S_ph == 2'd3) begin
                        S_ph <= 2'd0;
                        if (S_bit == 4'd8) begin
                            if (I_cmd[2]) begin
                                S_st   <= C_STOP;
                                S_hold <= 1'b0;
                            end
                            else begin
                                S_busy <= 1'b0;
                                O_done <= 1'b1;
                                S_hold <= 1'b1;
                                O_scl  <= 1'b0;
                                O_sda_oe <= 1'b0;
                            end
                        end
                        else begin
                            S_bit <= S_bit + 4'd1;
                        end
                    end
                    else
                        S_ph <= S_ph + 2'd1;
                end
                //----------------------------------------------------- STOP
                C_STOP: begin
                    case (S_ph)
                    2'd0: begin O_scl <= 1'b0; O_sda_oe <= 1'b1; O_sda_o <= 1'b0; end
                    2'd1: begin O_scl <= 1'b1; end
                    2'd2: begin O_scl <= 1'b1; O_sda_oe <= 1'b0; end
                    2'd3: begin O_scl <= 1'b1; O_sda_oe <= 1'b0; end
                    endcase
                    if (S_ph == 2'd3) begin
                        S_ph   <= 2'd0;
                        S_busy <= 1'b0;
                        S_hold <= 1'b0;
                        O_done <= 1'b1;
                    end
                    else
                        S_ph <= S_ph + 2'd1;
                end
                default: begin
                    S_busy <= 1'b0;
                    O_done <= 1'b1;
                end
                endcase
            end
        end
    end

endmodule

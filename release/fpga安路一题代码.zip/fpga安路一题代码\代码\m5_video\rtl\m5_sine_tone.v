//=============================================================================
//  m5_sine_tone.v  --  1 kHz sine test tone generator (M4)

`timescale 1ns / 10ps

module m5_sine_tone #(
    parameter [31:0] PHASE_INC = 32'd89478485
)(
    input  wire        I_clk,
    input  wire        I_rst,
    input  wire        I_tick,
    input  wire        I_en,
    output reg  [15:0] O_sample
);

    reg [31:0] S_phase;

    always @(posedge I_clk) begin
        if (I_rst)
            S_phase <= 32'd0;
        else if (I_tick && I_en)
            S_phase <= S_phase + PHASE_INC;
    end

    wire [9:0] S_idx  = S_phase[31:22];
    wire [7:0] S_addr = S_idx[8] ? ~S_idx[7:0] : S_idx[7:0];
    wire       S_neg  = S_idx[9];

    wire [15:0] S_mag;

    m5_sine_rom u_rom (
        .I_clk  (I_clk),
        .I_addr (S_addr),
        .O_data (S_mag)
    );

    // sign delayed by the same 1 clock as the ROM
    reg S_neg_r;
    always @(posedge I_clk) begin
        S_neg_r <= S_neg;
    end

    always @(posedge I_clk) begin
        if (I_rst)
            O_sample <= 16'd0;
        else if (!I_en)
            O_sample <= 16'd0;
        else if (S_neg_r)
            O_sample <= (~S_mag) + 16'd1;
        else
            O_sample <= S_mag;
    end

endmodule

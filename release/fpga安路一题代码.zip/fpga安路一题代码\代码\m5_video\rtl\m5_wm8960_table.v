//=============================================================================
//  m5_wm8960_table.v  --  WM8960 register initialisation table (M4)

`timescale 1ns / 10ps

module m5_wm8960_table (
    input  wire [4:0]  I_addr,
    output reg  [19:0] O_entry
);

    // number of valid entries (the sequencer stops here)
    localparam [4:0] TABLE_LEN = 5'd13;

    // delay codes
    localparam [2:0] D_NONE = 3'd0,
                     D_1MS  = 3'd1,
                     D_10MS = 3'd2,
                     D_100MS= 3'd3,
                     D_500MS= 3'd4;

    always @(*) begin
        case (I_addr)
        5'd0 : O_entry = {D_1MS,  8'h0F, 9'h000};
        5'd1 : O_entry = {D_NONE, 8'h04, 9'h000};
        5'd2 : O_entry = {D_NONE, 8'h07, 9'h002};
        5'd3 : O_entry = {D_NONE, 8'h0A, 9'h0FF};
        5'd4 : O_entry = {D_NONE, 8'h0B, 9'h0FF};
        5'd5 : O_entry = {D_NONE, 8'h22, 9'h100};
        5'd6 : O_entry = {D_NONE, 8'h25, 9'h100};
        5'd7 : O_entry = {D_500MS, 8'h19, 9'h0C0};
        5'd8 : O_entry = {D_10MS, 8'h1A, 9'h1E0};
        5'd9 : O_entry = {D_10MS, 8'h2F, 9'h00C};
        5'd10: O_entry = {D_10MS, 8'h05, 9'h000};
        5'd11: O_entry = {D_NONE, 8'h02, 9'h079};
        5'd12: O_entry = {D_NONE, 8'h03, 9'h079};

        default: O_entry = {D_NONE, 8'h00, 9'h000};
        endcase
    end

endmodule

//=============================================================================
//  m1_video_src.v
//  M1 milestone video source + frame-cache page controller (25 MHz pixel domain)

`timescale 1ns / 10ps

module m1_video_src #(
    parameter HTOTAL  = 800,
    parameter HSA     = 96,
    parameter HBP     = 48,
    parameter HFP     = 16,
    parameter HACTIVE = 640,

    parameter VTOTAL  = 525,
    parameter VSA     = 2,
    parameter VBP     = 33,
    parameter VFP     = 10,
    parameter VACTIVE = 480,

    parameter SWAP_FRAMES = 60
) (
    input  wire        I_clk,
    input  wire        I_rst,

    input  wire        I_key0_n,
    input  wire        I_sdram_ready,

    input  wire [31:0] I_rd1_data,
    input  wire [31:0] I_rd2_data,
    output wire        O_rd1_re,
    output wire        O_rd2_re,

    output wire        O_wr_start_tog,
    output wire        O_wr_page,
    input  wire        I_wr_done_tog,

    output reg         O_video_user,
    output reg         O_video_valid,
    output reg         O_video_last,
    output reg  [23:0] O_video_data
);

    localparam HBLANK = HTOTAL - HACTIVE;
    localparam VBLANK = VTOTAL - VACTIVE;

    reg [9:0] S_col_cnt;
    reg [9:0] S_line_cnt;

    always @(posedge I_clk) begin
        if (I_rst)
            S_col_cnt <= 10'd0;
        else if (S_col_cnt == HTOTAL - 1)
            S_col_cnt <= 10'd0;
        else
            S_col_cnt <= S_col_cnt + 10'd1;
    end

    always @(posedge I_clk) begin
        if (I_rst)
            S_line_cnt <= 10'd0;
        else if (S_col_cnt == HTOTAL - 1) begin
            if (S_line_cnt == VTOTAL - 1)
                S_line_cnt <= 10'd0;
            else
                S_line_cnt <= S_line_cnt + 10'd1;
        end
    end

    wire S_active  = (S_line_cnt >= VBLANK) && (S_col_cnt >= HBLANK);
    wire S_vstart  = (S_line_cnt == 10'd0) && (S_col_cnt == 10'd0);
    wire S_sof     = (S_line_cnt == VBLANK) && (S_col_cnt == HBLANK);
    wire S_eol     = S_active && (S_col_cnt == HTOTAL - 1);

    reg [1:0]  S_key_sync;
    reg [17:0] S_key_cnt;
    reg        S_key_stable;
    reg        S_key_stable_d;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_key_sync     <= 2'b11;
            S_key_cnt      <= 18'd0;
            S_key_stable   <= 1'b1;
            S_key_stable_d <= 1'b1;
        end else begin
            S_key_sync <= {S_key_sync[0], I_key0_n};
            if (S_key_sync[1] != S_key_stable) begin
                if (S_key_cnt == 18'h3FFFF) begin
                    S_key_cnt    <= 18'd0;
                    S_key_stable <= S_key_sync[1];
                end else begin
                    S_key_cnt <= S_key_cnt + 18'd1;
                end
            end else begin
                S_key_cnt <= 18'd0;
            end
            S_key_stable_d <= S_key_stable;
        end
    end

    wire S_key_press = S_key_stable_d && !S_key_stable;

    reg [2:0] S_done_sync;
    reg [1:0] S_ready_sync;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_done_sync  <= 3'b000;
            S_ready_sync <= 2'b00;
        end else begin
            S_done_sync  <= {S_done_sync[1:0],  I_wr_done_tog};
            S_ready_sync <= {S_ready_sync[0],   I_sdram_ready};
        end
    end

    wire S_done_pulse = S_done_sync[1] ^ S_done_sync[2];
    wire S_sdram_ok   = S_ready_sync[1];

    reg        S_ctrl_en;
    reg [1:0]  S_page_ok;
    reg        S_disp_page;
    reg        S_wr_page;
    reg        S_rd_en;
    reg        S_disp_en;
    reg        S_swap_pend;
    reg [5:0]  S_swap_div;
    reg        S_start_req;
    reg        S_start_d;

    wire S_auto_swap = S_vstart && (S_swap_div == SWAP_FRAMES - 1);
    wire S_vstart_ok = S_vstart && S_sdram_ok;
    wire [5:0] S_swap_next = (S_swap_div == SWAP_FRAMES - 1) ? 6'd0
                                                             : S_swap_div + 6'd1;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_ctrl_en    <= 1'b0;
            S_page_ok    <= 2'b00;
            S_disp_page  <= 1'b0;
            S_wr_page    <= 1'b0;
            S_rd_en      <= 1'b0;
            S_disp_en    <= 1'b0;
            S_swap_pend  <= 1'b0;
            S_swap_div   <= 6'd0;
            S_start_req  <= 1'b0;
            S_start_d    <= 1'b0;
        end else begin
            S_start_d <= S_start_req;

            // sticky manual swap request, cleared at every frame tick
            if (S_key_press)
                S_swap_pend <= 1'b1;
            else if (S_vstart)
                S_swap_pend <= 1'b0;

            // a page write completed -> that page may be displayed
            if (S_done_pulse)
                S_page_ok[S_wr_page] <= 1'b1;

            if (S_vstart_ok) begin
                if (!S_ctrl_en) begin
                    S_ctrl_en <= 1'b1;
                end

                if (S_ctrl_en) begin
                    if (!S_page_ok[S_disp_page]) begin
                        S_wr_page <= S_disp_page;
                        S_rd_en   <= 1'b0;
                    end else begin
                        S_rd_en   <= 1'b1;
                        if ((S_swap_pend || S_auto_swap) && S_page_ok[~S_disp_page]) begin
                            // swap during vertical blanking
                            S_disp_page <= ~S_disp_page;
                            S_wr_page   <= S_disp_page;
                        end else begin
                            S_wr_page   <= ~S_disp_page;
                        end
                    end

                    S_swap_div  <= S_swap_next;
                    S_start_req <= ~S_start_req;

                    S_disp_en <= S_rd_en;
                end
            end
        end
    end

    // the writer samples this level 2..3 cycles after the toggle edge
    assign O_wr_start_tog = S_start_d;
    assign O_wr_page      = S_wr_page;

    wire [23:0] S_pix = S_disp_page ? I_rd2_data[23:0] : I_rd1_data[23:0];

    always @(posedge I_clk) begin
        if (I_rst) begin
            O_video_valid <= 1'b0;
            O_video_user  <= 1'b0;
            O_video_last  <= 1'b0;
            O_video_data  <= 24'd0;
        end else begin
            O_video_valid <= S_active;
            O_video_user  <= S_sof;
            O_video_last  <= S_eol;
            O_video_data  <= S_disp_en ? S_pix : 24'h000000;
        end
    end

    assign O_rd1_re = S_active && S_rd_en;
    assign O_rd2_re = S_active && S_rd_en;

endmodule

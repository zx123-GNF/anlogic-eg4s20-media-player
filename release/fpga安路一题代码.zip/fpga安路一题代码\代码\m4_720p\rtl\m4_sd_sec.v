//=============================================================================
//  m4_sd_sec.v
//  Thin wrapper around the vendor SD-card SPI engine  (sd_card_control.v,

`timescale 1ns / 10ps

module m4_sd_sec (
    input  wire        I_clk,
    input  wire        I_rst,

    input  wire        I_init,
    input  wire        I_start,
    input  wire [31:0] I_lba,
    output reg         O_busy,
    output reg         O_done,
    output reg         O_err,

    input  wire [8:0]  I_ram_addr,
    output wire [7:0]  O_ram_dout,

    // SD card pins
    output wire        O_sd_clk,
    output wire        O_sd_mosi,
    output wire        O_sd_cs_n,
    input  wire        I_sd_miso
);

    localparam S_IDLE = 2'd0;
    localparam S_GO   = 2'd1;
    localparam S_RUN  = 2'd2;
    localparam S_RST  = 2'd3;

    reg [1:0]  S_st;
    reg [2:0]  S_rcnt;
    reg        S_init_q;
    reg [31:0] S_lba_q;
    reg [28:0] S_wd;
    reg        S_rst_sd;

    wire S_sd_done;
    wire S_sd_idle;
    wire S_start_pulse = (S_st == S_GO);

    wire [28:0] S_wd_limit = S_init_q ? 29'h0FFFFFFF
                                      : 29'h003FFFFF;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_st     <= S_IDLE;
            S_init_q <= 1'b0;
            S_lba_q  <= 32'd0;
            S_wd     <= 29'd0;
            S_rst_sd <= 1'b0;
            O_busy   <= 1'b0;
            O_done   <= 1'b0;
            O_err    <= 1'b0;
        end else begin
            O_done   <= 1'b0;
            O_err    <= 1'b0;
            S_rst_sd <= 1'b0;

            case (S_st)
                S_IDLE: begin
                    O_busy <= 1'b0;
                    if (I_start) begin
                        S_init_q <= I_init;
                        S_lba_q  <= I_lba;
                        S_wd     <= 29'd0;
                        S_rcnt   <= 3'd0;
                        S_st     <= S_RST;
                    end
                end

                S_RST: begin
                    S_rst_sd <= 1'b1;
                    if (S_rcnt == 3'd7) begin
                        S_rst_sd <= 1'b0;
                        S_st     <= S_GO;
                    end else
                        S_rcnt <= S_rcnt + 3'd1;
                end

                S_GO: begin
                    O_busy <= 1'b1;
                    S_st   <= S_RUN;
                end

                S_RUN: begin
                    if (S_sd_done) begin
                        O_busy <= 1'b0;
                        O_done <= 1'b1;
                        S_st   <= S_IDLE;
                    end else if (S_wd >= S_wd_limit) begin
                        // abort the transaction: the vendor FSM has no abort
                        O_busy   <= 1'b0;
                        O_err    <= 1'b1;
                        S_rst_sd <= 1'b1;
                        S_st     <= S_IDLE;
                    end else begin
                        S_wd <= S_wd + 29'd1;
                    end
                end

                default: S_st <= S_IDLE;
            endcase
        end
    end

    sd_card_control #(
        .clock_freq  (100_000_000),
        .spi_lowfreq (400_000),
        .spi_highfreq(5_000_000)
    ) u_sd (
        .mosi        (O_sd_mosi),
        .sclk        (O_sd_clk),
        .cs_n        (O_sd_cs_n),
        .idle        (S_sd_idle),
        .done        (S_sd_done),

        .rd_ram_dout (O_ram_dout),
        .rd_ram_addr (I_ram_addr),

        .wr_ram_din  (8'd0),
        .wr_ram_addr (9'd0),
        .wr_ram_wea  (1'b0),

        .sector_addr (S_lba_q[27:0]),
        .miso        (I_sd_miso),
        .start       (S_start_pulse),
        .mode        (S_init_q ? 2'd0 : 2'd2),

        .clk         (I_clk),
        .rst         (I_rst | S_rst_sd)
    );

endmodule

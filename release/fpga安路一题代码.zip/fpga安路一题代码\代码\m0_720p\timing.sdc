#-----------------------------------------------------------------------------
# timing.sdc  --  m0_720p probe (1280x720, vendor pll_hdmi1_4b clocking)

create_clock -name clk_50m -period 20.000 -waveform {0 10.000} [get_ports {clk}]

# 50 * 22 = 1100 MHz (VCO), declared on the unused C0 tap
create_generated_clock -name clk_vco -source [get_ports {clk}] -multiply_by 22 \
    [get_pins {u_pll/pll_inst.clkc[0]}]

# 1100 / 15 = 73.333 MHz pixel clock
create_generated_clock -name pixel_clk -source [get_pins {u_pll/pll_inst.clkc[0]}] \
    -divide_by 15 \
    [get_pins {u_pll/pll_inst.clkc[1]}]

create_generated_clock -name serial_clk -source [get_pins {u_pll/pll_inst.clkc[0]}] \
    -divide_by 3 \
    [get_pins {u_pll/pll_inst.clkc[2]}]

set_clock_groups -exclusive \
    -group [get_clocks {clk_50m}] \
    -group [get_clocks {pixel_clk}] \
    -group [get_clocks {serial_clk}]

#-----------------------------------------------------------------------------
#  timing.sdc  --  M4 : M3 player + WM8960 audio (AC208 / EG4S20BG256)

create_clock -name clk_50m -period 20.000 -waveform {0 10.000} [get_ports {clk}]

create_generated_clock -name pixel_clk \
    -source [get_ports {clk}] -divide_by 2 \
    [get_pins {u_pll/pll_inst.clkc[1]}]

create_generated_clock -name serial_clk \
    -source [get_pins {u_pll/pll_inst.clkc[1]}] -multiply_by 5 \
    [get_pins {u_pll/pll_inst.clkc[2]}]

# 100.000 MHz SDRAM controller clock = 2 x 50.000 MHz
create_generated_clock -name sdram_clk \
    -source [get_ports {clk}] -multiply_by 2 \
    [get_pins {u_sdram/sdram_pll1/pll_inst.clkc[0]}]

create_generated_clock -name mclk_audio \
    -source [get_ports {clk}] -divide_by 4 \
    [get_pins {u_pll_audio/pll_inst.clkc[0]}]

set_clock_groups -exclusive \
    -group [get_clocks {clk_50m}] \
    -group [get_clocks {pixel_clk}] \
    -group [get_clocks {serial_clk}] \
    -group [get_clocks {sdram_clk}] \
    -group [get_clocks {mclk_audio}]

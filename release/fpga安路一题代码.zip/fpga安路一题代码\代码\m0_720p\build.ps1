﻿
$ErrorActionPreference = 'Stop'

$td   = 'E:\bin\td_commands_prompt.exe'
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition
$flow = ($root -replace '\\', '/') + '/run_flow.tcl'
$runs = Join-Path $root 'm0_720p_Runs'
$bit  = Join-Path $runs 'phy_1\m0_720p.bit'

foreach ($r in @('syn_1', 'phy_1')) {
    $dir = Join-Path $runs $r
    Push-Location $dir
    & $td $flow *> console_ci.log
    $rc = $LASTEXITCODE
    Pop-Location

    $log = Get-Content (Join-Path $dir 'console_ci.log') -Raw
    if ($rc -ne 0 -or $log -notmatch 'TD_FLOW_OK') {
        $err = ($log -split "`n" | Select-String -Pattern 'ERROR|CRITICAL-WARNING|TD_FLOW_FAILED' |
                Select-Object -Last 15 | ForEach-Object { $_.Line.Trim() }) -join "`n"
        throw "TD flow failed in $r (exit $rc)`n$err`nsee $dir\console_ci.log"
    }
    Write-Host "OK  $r"
}

if (-not (Test-Path $bit)) { throw "bitstream missing: $bit" }
$len = (Get-Item $bit).Length
Write-Host ("OK  bitstream {0} ({1} bytes)" -f $bit, $len)
Get-Content (Join-Path $runs 'phy_1\m0_720p_phy.ts')

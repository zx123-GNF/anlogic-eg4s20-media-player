//=============================================================================
//  m6_vdec.v  --  M5V1 video decoder + frame pacer (100 MHz domain)

`timescale 1ns / 10ps

module m6_vdec #(
    parameter integer CLK_HZ = 100_000_000,
    parameter integer FPS    = 15
) (
    input  wire        I_clk,
    input  wire        I_rst,
    input  wire        I_sdram_ready,

    // byte stream from m6_stream
    input  wire        I_byte_valid,
    input  wire [7:0]  I_byte,
    output wire        O_byte_ready,
    input  wire        I_eof,

    // SDRAM write ring (WR1)
    output wire        O_wr,
    output wire [31:0] O_wr_data,
    input  wire        I_wr_full,
    output reg         O_wr_load,
    output wire [20:0] O_wr_addr,

    input  wire        I_start_page,

    output reg         O_pg_done,
    output reg         O_pg_page,
    output reg         O_clip_end,

    // status
    output wire        O_busy,
    output reg  [15:0] O_frame_cnt,
    output reg  [5:0]  O_st,
    output reg  [2:0]  O_err,

    // audio chunk (mono s16) for the I2S side
    output reg         O_aud_we,
    output reg  [15:0] O_aud_data,

    // bring-up observability (UART status line)
    output wire [31:0] O_dbg_vbyt,
    output wire [31:0] O_dbg_px,
    output wire [15:0] O_dbg_audn,
    output wire [31:0] O_dbg_len,
    output wire [31:0] O_dbg_endv,
    output wire [31:0] O_dbg_hdrb,
    output wire [31:0] O_dbg_raw32,
    output wire [31:0] O_dbg_rawh
);

    localparam integer PERIOD = CLK_HZ / FPS;

    reg [31:0] S_tmr;
    wire S_tmr_wrap = (S_tmr >= PERIOD - 1);

    always @(posedge I_clk) begin
        if (I_rst)           S_tmr <= 32'd0;
        else if (S_tmr_wrap) S_tmr <= 32'd0;
        else                 S_tmr <= S_tmr + 32'd1;
    end

    reg  [255:0] S_hdr;
    reg  [7:0]   S_hcnt;
    reg  [63:0]  S_fhdr;
    reg  [3:0]   S_fcnt;
    reg  [31:0]  S_len;
    reg  [15:0]  S_aud_n;
    reg  [15:0]  S_aud_i;
    reg  [31:0]  S_frames;
    reg  [15:0] S_fr_left;
    reg  [16:0] S_aud_left;
    reg  [8:0]   S_rows;
    reg  [31:0] S_endv;
    reg         S_endv_cap;

    // deterministic frame framing (see the header comments)
    reg  [31:0] S_pend;
    reg  [31:0] S_skip;
    reg  [31:0] S_hdrb;
    reg         S_align_b;

    reg  [7:0] S_row [0:319];
    reg  [8:0] S_x;
    reg  [9:0] S_tx;
    reg        S_pass;
    reg  [7:0] S_pix;
    reg  [12:0] S_left;
    reg        S_rep;
    reg  [15:0] S_tok;
    reg  [7:0] S_aud_hi;
    reg        S_aud_lo;

    wire [11:0] S_cnt = S_tok[11:0];

    // RGB332 -> RGB888 by bit replication (7 -> 255, 1 -> 36, ...)
    wire [7:0] S_src = S_row[S_tx[9:1]];
    wire [7:0] S_r8  = {S_src[7:5], S_src[7:6], S_src[7:5]};
    wire [7:0] S_g8  = {S_src[4:2], S_src[4:3], S_src[4:2]};
    wire [7:0] S_b8  = {S_src[1:0], S_src[1:0], S_src[1:0], S_src[1:0]};
    wire [23:0] S_rgb = {S_r8, S_g8, S_b8};

    assign O_wr       = (S_st == V_EMIT) && !I_wr_full;
    assign O_wr_data  = {8'h00, S_rgb};

    assign O_wr_addr = (O_wr_load && I_start_page) ? 21'h04B000 : 21'd0;

    assign O_busy     = (S_st != V_WAIT);

    // bring-up counters
    reg [31:0] S_vbyt;
    reg [31:0] S_px;
    wire W_consume = I_byte_valid && O_byte_ready;

    assign O_dbg_vbyt = S_vbyt;
    assign O_dbg_px   = S_px;
    assign O_dbg_audn = S_aud_n;
    assign O_dbg_len  = S_len;
    assign O_dbg_endv = S_endv;
    assign O_dbg_hdrb = S_hdrb;

    reg  [31:0] S_raw32;
    reg  [31:0] S_rawh;
    always @(posedge I_clk) begin
        if (I_rst) begin
            S_raw32 <= 32'd0;
            S_rawh  <= 32'd0;
        end else if (W_consume) begin
            if ((S_vbyt >= 32'd4)  && (S_vbyt < 32'd8))  S_rawh  <= {S_rawh[23:0],  I_byte};
            if ((S_vbyt >= 32'd32) && (S_vbyt < 32'd36)) S_raw32 <= {S_raw32[23:0], I_byte};
        end
    end
    assign O_dbg_raw32 = S_raw32;
    assign O_dbg_rawh  = S_rawh;

    wire [31:0] S_vbyt_nx = S_vbyt + {31'd0, W_consume};
    wire [31:0] S_len_w   = S_fhdr[55:24];
    wire [255:0] S_hdr_nx = {S_hdr[247:0], I_byte};
    wire [15:0] S_bpp_a   = S_hdr_nx[175:160];
    wire [15:0] S_bpp_b   = S_hdr_nx[167:152];
    wire [31:0] S_fr_w    = (S_bpp_a == 16'd1) ? S_hdr_nx[159:128]
                                               : S_hdr_nx[151:120];
    wire [31:0] S_fr_n    = ((S_fr_w == 32'd0) || (S_fr_w > 32'd10000))
                            ? 32'd60000 : S_fr_w;

    localparam [5:0]
        V_WAIT   = 6'd0,
        V_HDR_M  = 6'd1,
        V_HDR_5  = 6'd2,
        V_HDR_V  = 6'd3,
        V_HDR_1  = 6'd4,
        V_HDR_R  = 6'd5,
        V_FRAME  = 6'd6,
        V_FHDR   = 6'd7,
        V_TOKEN0 = 6'd8,
        V_TOKEN1 = 6'd9,
        V_PARSE  = 6'd10,
        V_REPPIX = 6'd11,
        V_WRITE  = 6'd12,
        V_EMIT   = 6'd13,
        V_AUDIO  = 6'd14,
        V_DONE   = 6'd15,
        V_ALIGN1 = 6'd16,
        V_PSKIP  = 6'd17,
        V_PEND   = 6'd18;

    reg [5:0] S_st;

    wire S_byte_want =
           (S_st == V_HDR_M)  || (S_st == V_HDR_5) || (S_st == V_HDR_V) ||
           (S_st == V_HDR_1)  || (S_st == V_HDR_R) || (S_st == V_ALIGN1) ||
           (S_st == V_FHDR)   || (S_st == V_TOKEN0)|| (S_st == V_TOKEN1) ||
           (S_st == V_REPPIX) || (S_st == V_PSKIP) || (S_st == V_AUDIO)  ||
           ((S_st == V_WRITE) && !S_rep);
    assign O_byte_ready = S_byte_want;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_st         <= V_WAIT;
            S_hdr        <= 256'd0;
            S_hcnt       <= 8'd0;
            S_fhdr       <= 64'd0;
            S_fcnt       <= 4'd0;
            S_len        <= 32'd0;
            S_aud_n      <= 16'd0;
            S_aud_i      <= 16'd0;
            S_frames     <= 32'd0;
            S_fr_left    <= 16'd1;
            S_aud_left   <= 17'd0;
            S_aud_lo     <= 1'b0;
            S_aud_hi     <= 8'd0;
            S_pix        <= 8'd0;
            S_left       <= 13'd0;
            S_rep        <= 1'b0;
            S_tok        <= 16'd0;
            S_x          <= 9'd0;
            S_tx         <= 10'd0;
            S_pass       <= 1'b0;
            O_wr_load    <= 1'b0;
            O_pg_done    <= 1'b0;
            O_pg_page    <= 1'b0;
            O_clip_end   <= 1'b0;
            O_frame_cnt  <= 16'd0;
            O_st         <= V_WAIT;
            O_err        <= 3'd0;
            O_aud_we     <= 1'b0;
            O_aud_data   <= 16'd0;
            S_vbyt       <= 32'd0;
            S_px         <= 32'd0;
            S_rows       <= 9'd0;
            S_endv       <= 32'd0;
            S_endv_cap   <= 1'b0;
            S_pend       <= 32'd0;
            S_skip       <= 32'd0;
            S_hdrb       <= 32'd0;
            S_align_b    <= 1'b0;
        end else begin
            O_st         <= S_st;
            O_wr_load    <= 1'b0;
            O_aud_we     <= 1'b0;
            O_pg_done    <= 1'b0;
            O_clip_end   <= 1'b0;

            if (W_consume) S_vbyt <= S_vbyt + 32'd1;

            case (S_st)
            //------------------------------------------------- start
            V_WAIT: begin
                if (I_sdram_ready) begin
                    O_wr_load <= 1'b1;
                    S_st      <= V_HDR_M;
                end
            end
            //------------------------------------------------- header resync
            V_HDR_M: begin
                if (I_byte_valid && I_byte == 8'h4D) S_st <= V_HDR_5;
            end
            V_HDR_5: begin
                if (I_byte_valid) S_st <= (I_byte == 8'h35) ? V_HDR_V : V_HDR_M;
            end
            V_HDR_V: begin
                if (I_byte_valid) S_st <= (I_byte == 8'h56) ? V_HDR_1 : V_HDR_M;
            end
            V_HDR_1: begin
                if (I_byte_valid) begin
                    if (I_byte == 8'h31) begin
                        S_hdr  <= {S_hdr[247:0], I_byte};
                        S_hcnt <= 8'd1;
                        S_st   <= V_HDR_R;
                    end else
                        S_st <= V_HDR_M;
                end
            end
            V_HDR_R: begin
                if (I_byte_valid) begin
                    S_hdr  <= {S_hdr[247:0], I_byte};
                    S_hcnt <= S_hcnt + 8'd1;
                    if (S_hcnt == 8'd28) begin
                        if (S_bpp_a == 16'd1) begin
                            S_align_b <= 1'b0;
                            S_frames  <= S_fr_n;
                            S_fr_left <= S_fr_n[15:0];
                            S_st      <= V_FRAME;
                        end else if (S_bpp_b == 16'd1) begin
                            S_align_b <= 1'b1;
                            S_frames  <= S_fr_n;
                            S_fr_left <= S_fr_n[15:0];
                            S_st      <= V_ALIGN1;
                        end else begin
                            O_err <= 3'd1;
                            S_st  <= V_HDR_M;
                        end
                    end
                end
            end
            //------------------------------------------------- one byte realign
            V_ALIGN1: begin
                if (I_byte_valid) begin
                    S_fcnt <= 4'd0;
                    S_fhdr <= 64'd0;
                    S_st   <= V_FRAME;
                end
            end
            //------------------------------------------------- frame boundary
            V_FRAME: begin
                if (S_tmr_wrap) begin
                    S_fcnt  <= 4'd0;
                    S_fhdr  <= 64'd0;
                    S_hdrb  <= 32'd0;
                    S_st    <= V_FHDR;
                end
            end
            V_FHDR: begin
                if (I_byte_valid) begin
                    S_fhdr <= {S_fhdr[55:0], I_byte};
                    if (S_fcnt < 4'd4) S_hdrb <= {S_hdrb[23:0], I_byte};
                    S_fcnt <= S_fcnt + 4'd1;
                    if (S_fcnt == 4'd7) begin
                        // S_fhdr holds bytes b0..b6 (b0 in bits 55:48), I_byte b7
                        S_len   <= S_len_w;
                        S_aud_n <= (S_fhdr[23:8] > 16'd8000) ? 16'd0
                                                           : S_fhdr[23:8];
                        S_aud_left <= ((S_fhdr[23:8] == 16'd0) ||
                                       (S_fhdr[23:8] > 16'd8000))
                                      ? 17'd0 : {S_fhdr[23:8], 1'b0};
                        S_aud_i <= 16'd0;
                        S_x     <= 9'd0;
                        S_px    <= 32'd0;
                        S_rows  <= 9'd0;
                        if ((S_len_w < 32'd256) || (S_len_w > 32'd65535)) begin
                            O_err <= 3'd4;
                            S_st  <= V_HDR_M;
                        end else
                            S_st <= V_PEND;
                    end
                end
            end
            V_PEND: begin
                S_pend <= S_vbyt + S_len;
                S_st   <= V_TOKEN0;
            end
            //------------------------------------------------- RLE tokens
            V_TOKEN0: begin
                if (I_byte_valid) begin
                    S_tok[15:8] <= I_byte;
                    S_st        <= V_TOKEN1;
                end
            end
            V_TOKEN1: begin
                if (I_byte_valid) begin
                    S_tok[7:0] <= I_byte;
                    S_st       <= V_PARSE;
                end
            end
            V_PARSE: begin
                if (S_tok[15:12] == 4'd0) begin
                    // end of this frame's payload
                    S_aud_i  <= 16'd0;
                    S_aud_lo <= 1'b0;
                    if (S_rows != 9'd240) O_err <= 3'd2;
                    if (!S_endv_cap) begin S_endv <= S_vbyt_nx; S_endv_cap <= 1'b1; end
                    if (S_vbyt_nx < S_pend) begin
                        S_skip <= S_pend - S_vbyt_nx;
                        S_st   <= V_PSKIP;
                    end else
                        S_st <= (S_aud_n != 16'd0) ? V_AUDIO : V_DONE;
                end else if (S_vbyt_nx >= S_pend) begin
                    // payload complete but the end token never showed up
                    O_err    <= 3'd5;
                    S_aud_i  <= 16'd0;
                    S_aud_lo <= 1'b0;
                    if (!S_endv_cap) begin S_endv <= S_vbyt_nx; S_endv_cap <= 1'b1; end
                    S_st <= (S_aud_n != 16'd0) ? V_AUDIO : V_DONE;
                end else begin
                    S_left <= {1'b0, S_cnt} + 13'd1;
                    S_rep  <= (S_tok[15:12] == 4'd1);
                    S_st   <= (S_tok[15:12] == 4'd1) ? V_REPPIX : V_WRITE;
                end
            end
            //------------------------------------------------- payload discard
            V_PSKIP: begin
                if (I_byte_valid) begin
                    S_skip <= S_skip - 32'd1;
                    if (S_skip == 32'd1)
                        S_st <= (S_aud_n != 16'd0) ? V_AUDIO : V_DONE;
                end
            end
            V_REPPIX: begin
                if (I_byte_valid) begin
                    S_pix <= I_byte;
                    S_st  <= V_WRITE;
                end
            end
            V_WRITE: begin
                if (S_rep) begin
                    // no bytes to consume, just replicate
                    S_row[S_x] <= S_pix;
                    S_px       <= S_px + 32'd1;
                    S_x        <= S_x + 9'd1;
                    S_left     <= S_left - 13'd1;
                    if (S_x == 9'd319) begin
                        S_x    <= 9'd0;
                        S_tx   <= 10'd0;
                        S_pass <= 1'b0;
                        S_st   <= V_EMIT;
                    end else if (S_left == 13'd1) begin
                        S_st <= V_TOKEN0;
                    end
                end else begin
                        if (I_byte_valid) begin
                        S_row[S_x] <= I_byte;
                        S_px       <= S_px + 32'd1;
                        S_x        <= S_x + 9'd1;
                        S_left     <= S_left - 13'd1;
                        if (S_x == 9'd319) begin
                            S_x    <= 9'd0;
                            S_tx   <= 10'd0;
                            S_pass <= 1'b0;
                            S_st   <= V_EMIT;
                        end else if (S_left == 13'd1) begin
                            S_st <= V_TOKEN0;
                        end
                    end
                end
            end
            //------------------------------------------------- emit two rows
            V_EMIT: begin
                if (!I_wr_full) begin
                    if (S_tx == 10'd639) begin
                        S_tx <= 10'd0;
                        if (S_pass == 1'b0)
                            S_pass <= 1'b1;
                        else begin
                            S_pass <= 1'b0;
                            S_rows <= S_rows + 9'd1;
                            S_st   <= (S_left != 13'd0) ? V_WRITE : V_TOKEN0;
                        end
                    end else
                        S_tx <= S_tx + 10'd1;
                end
            end
            V_AUDIO: begin
                if (I_byte_valid) begin
                    if (!S_aud_lo) begin
                        S_aud_hi <= I_byte;
                        S_aud_lo <= 1'b1;
                    end else begin
                        O_aud_we   <= 1'b1;
                        O_aud_data <= {I_byte, S_aud_hi};
                        S_aud_lo   <= 1'b0;
                    end
                    S_aud_i    <= S_aud_i + 16'd1;
                    S_aud_left <= S_aud_left - 17'd1;
                    if (S_aud_left == 17'd1) S_st <= V_DONE;
                end
            end
            //------------------------------------------------- frame done
            V_DONE: begin
                O_pg_done <= 1'b1;
                O_pg_page <= I_start_page ^ O_frame_cnt[0];
                if (S_fr_left == 16'd1) begin
                    O_clip_end  <= 1'b1;
                    O_frame_cnt <= 16'd0;
                    S_fr_left   <= S_frames[15:0];
                    S_st        <= V_HDR_M;
                end else begin
                    O_frame_cnt <= O_frame_cnt + 16'd1;
                    S_fr_left   <= S_fr_left - 16'd1;
                    S_st        <= V_FRAME;
                end
            end
            default: S_st <= V_WAIT;
            endcase
        end
    end

endmodule

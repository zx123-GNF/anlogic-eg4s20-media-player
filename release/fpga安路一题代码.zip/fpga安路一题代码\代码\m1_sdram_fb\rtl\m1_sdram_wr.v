//=============================================================================
//  m1_sdram_wr.v
//  M1 test-pattern writer for page A / page B (100 MHz SDRAM domain)

`timescale 1ns / 10ps

module m1_sdram_wr #(
    parameter HACTIVE         = 640,
    parameter VACTIVE         = 480,
    parameter BAR_STEP_FRAMES = 60
) (
    input  wire        I_clk,
    input  wire        I_rst,

    input  wire        I_start_tog,
    input  wire        I_page,
    input  wire        I_fifo_full,

    output wire        O_wr,
    output wire [31:0] O_wr_data,
    output reg         O_done_tog
);

    reg [2:0] S_start_sync;
    reg [1:0] S_page_sync;

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_start_sync <= 3'b000;
            S_page_sync  <= 2'b00;
        end else begin
            S_start_sync <= {S_start_sync[1:0], I_start_tog};
            S_page_sync  <= {S_page_sync[0],    I_page};
        end
    end

    wire S_start_pulse = S_start_sync[1] ^ S_start_sync[2];

    reg        S_busy;
    reg [9:0]  S_x;
    reg [8:0]  S_y;
    reg        S_page_q;
    reg [5:0]  S_bar_div;
    reg [9:0]  S_bar_x;

    wire [9:0] S_bar_end = S_bar_x + 10'd8;

    reg [23:0] S_pat;
    always @(*) begin
        if (S_x < 10'd8 || S_x >= HACTIVE - 8 || S_y < 9'd8 || S_y >= VACTIVE - 8)
            S_pat = S_page_q ? 24'hFF00FF : 24'h00FF00;
        else if (S_x >= S_bar_x && S_x < S_bar_end)
            S_pat = 24'hFFFFFF;
        else
            S_pat = {S_x[9:2], S_y[8:1], 8'h40};
    end

    wire S_accept = S_busy && !I_fifo_full;

    assign O_wr      = S_accept;
    assign O_wr_data = {8'h00, S_pat};

    always @(posedge I_clk) begin
        if (I_rst) begin
            S_busy     <= 1'b0;
            S_x        <= 10'd0;
            S_y        <= 9'd0;
            S_page_q   <= 1'b0;
            S_bar_div  <= 6'd0;
            S_bar_x    <= 10'd0;
            O_done_tog <= 1'b0;
        end else begin
            if (S_start_pulse && !S_busy) begin
                S_busy   <= 1'b1;
                S_x      <= 10'd0;
                S_y      <= 9'd0;
                S_page_q <= S_page_sync[1];
            end else if (S_accept) begin
                if (S_x == HACTIVE - 1) begin
                    S_x <= 10'd0;
                    if (S_y == VACTIVE - 1) begin
                        // page complete
                        S_y        <= 9'd0;
                        S_busy     <= 1'b0;
                        O_done_tog <= ~O_done_tog;

                        if (S_bar_div == BAR_STEP_FRAMES - 1) begin
                            S_bar_div <= 6'd0;
                            S_bar_x   <= (S_bar_x >= HACTIVE - 8)
                                         ? 10'd0 : (S_bar_x + 10'd8);
                        end else begin
                            S_bar_div <= S_bar_div + 6'd1;
                        end
                    end else begin
                        S_y <= S_y + 9'd1;
                    end
                end else begin
                    S_x <= S_x + 10'd1;
                end
            end
        end
    end

endmodule
